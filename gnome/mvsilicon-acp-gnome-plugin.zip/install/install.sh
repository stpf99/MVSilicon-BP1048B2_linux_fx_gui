#!/usr/bin/env bash
# Instalacja apletu GNOME + acpd + edytora GTK dla MVSilicon BP1048B2
# Obsługuje: pliki użytkownika, systemd --user, udev (sudo), chmod bieżącego USB
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EXT_UUID="mvsilicon-acp@mvsilicon"
SHARE="${XDG_DATA_HOME:-$HOME/.local/share}"
EXT_DIR="$SHARE/gnome-shell/extensions/$EXT_UUID"
APP_DIR="$SHARE/mvsilicon-acp"
DBUS_DIR="$SHARE/dbus-1/services"
SYSTEMD_USER="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
UDEV_RULES_SRC="$ROOT/install/99-mvsilicon-bp1048.rules"
UDEV_RULES_DST="/etc/udev/rules.d/99-mvsilicon-bp1048.rules"

echo "==> Katalog aplikacji: $APP_DIR"
mkdir -p "$APP_DIR" "$DBUS_DIR" "$SYSTEMD_USER"

# ── Daemon + GTK GUI ──────────────────────────────────────────────────────
cp -v "$ROOT/acpd.py" "$APP_DIR/"
cp -v "$ROOT/acp_gui_gtk.py" "$APP_DIR/"
chmod +x "$APP_DIR/acpd.py" "$APP_DIR/acp_gui_gtk.py"

# Helper: chmod USB po każdym podłączeniu (gdy udev jeszcze nie zadziałał)
cat > "$APP_DIR/fix-usb-perms.sh" <<'HELPER'
#!/usr/bin/env bash
# Nadaje rw na /dev/bus/usb/BBB/DDD dla 8888:1719 (wymaga sudo)
set -euo pipefail
mapfile -t lines < <(lsusb -d 8888:1719 2>/dev/null || true)
if [[ ${#lines[@]} -eq 0 ]]; then
  echo "Brak urządzenia 8888:1719 — podepnij DSP i spróbuj ponownie."
  exit 1
fi
for line in "${lines[@]}"; do
  # "Bus 001 Device 012: ID 8888:1719 ..."
  bus=$(echo "$line" | awk '{printf "%03d", $2}')
  dev=$(echo "$line" | awk '{printf "%03d", $4}' | tr -d ':')
  node="/dev/bus/usb/${bus}/${dev}"
  if [[ -e "$node" ]]; then
    sudo chmod a+rw "$node"
    # wyłącz autosuspend na sysfs, jeśli dostępne
    sys=$(find /sys/bus/usb/devices -maxdepth 1 -type l 2>/dev/null | while read -r d; do
      if [[ -f "$d/idVendor" ]] && grep -qi '^8888$' "$d/idVendor" 2>/dev/null \
         && [[ -f "$d/idProduct" ]] && grep -qi '^1719$' "$d/idProduct" 2>/dev/null; then
        echo "$d"
      fi
    done | head -1)
    if [[ -n "${sys:-}" ]]; then
      if [[ -f "$sys/power/control" ]]; then
        echo on | sudo tee "$sys/power/control" >/dev/null || true
      fi
      if [[ -f "$sys/power/autosuspend_delay_ms" ]]; then
        echo -1 | sudo tee "$sys/power/autosuspend_delay_ms" >/dev/null || true
      fi
      echo "  power/control=on  ($sys)"
    fi
    echo "OK: $node  ($(ls -l "$node" | awk '{print $1,$3,$4}'))"
  else
    echo "Brak węzła $node"
  fi
done
HELPER
chmod +x "$APP_DIR/fix-usb-perms.sh"

# ── D-Bus activation WYŁĄCZONA ────────────────────────────────────────────
# Nie instalujemy org.mvsilicon.Acp.service — koliduje z systemd (dwa acpd).
# Usuń stary plik jeśli istnieje:
rm -f "$DBUS_DIR/org.mvsilicon.Acp.service"
echo "    D-Bus activation: usunięte (tylko systemd --user)"

# ── systemd --user (Type=simple) ──────────────────────────────────────────
# Zatrzymaj stare instancje, żeby nie blokowały nazwy D-Bus
systemctl --user stop mvsilicon-acpd.service 2>/dev/null || true
pkill -f '[a]cpd\.py' 2>/dev/null || true
sleep 0.3

sed "s|%h|$HOME|g" "$ROOT/install/mvsilicon-acpd.service" > "$SYSTEMD_USER/mvsilicon-acpd.service"
systemctl --user daemon-reload
systemctl --user enable mvsilicon-acpd.service
echo "    systemd unit → mvsilicon-acpd.service (Type=simple, enabled)"

# ── Extension ─────────────────────────────────────────────────────────────
echo "==> Extension → $EXT_DIR"
mkdir -p "$EXT_DIR/schemas"
cp -v "$ROOT/mvsilicon-acp@mvsilicon/metadata.json" "$EXT_DIR/"
cp -v "$ROOT/mvsilicon-acp@mvsilicon/extension.js" "$EXT_DIR/"
cp -v "$ROOT/mvsilicon-acp@mvsilicon/prefs.js" "$EXT_DIR/"
cp -v "$ROOT/mvsilicon-acp@mvsilicon/schemas/"*.xml "$EXT_DIR/schemas/"
# skompilowany schema jeśli jest w źródle
if [[ -f "$ROOT/mvsilicon-acp@mvsilicon/schemas/gschemas.compiled" ]]; then
  cp -v "$ROOT/mvsilicon-acp@mvsilicon/schemas/gschemas.compiled" "$EXT_DIR/schemas/" || true
fi
if command -v glib-compile-schemas >/dev/null; then
  glib-compile-schemas "$EXT_DIR/schemas/"
  echo "    schemas compiled"
fi
gsettings set org.gnome.shell.extensions.mvsilicon-acp full-editor-path \
  "$APP_DIR/acp_gui_gtk.py" 2>/dev/null || true

# ── udev (wymaga sudo) ────────────────────────────────────────────────────
echo ""
echo "==> udev rules (MODE=0666 + uaccess + no autosuspend)"
if [[ -f "$UDEV_RULES_SRC" ]]; then
  if command -v sudo >/dev/null 2>&1; then
    if sudo -n true 2>/dev/null || sudo -v; then
      sudo mkdir -p /etc/udev/rules.d
      sudo cp -v "$UDEV_RULES_SRC" "$UDEV_RULES_DST"
      sudo udevadm control --reload-rules
      # trigger tylko naszego urządzenia, nie całego USB
      sudo udevadm trigger -s usb -a idVendor=8888 -a idProduct=1719 2>/dev/null \
        || sudo udevadm trigger --action=add 2>/dev/null || true
      echo "    zainstalowano: $UDEV_RULES_DST"
    else
      echo "    ⚠ brak sudo — zainstaluj ręcznie:"
      echo "      sudo cp $UDEV_RULES_SRC $UDEV_RULES_DST"
      echo "      sudo udevadm control --reload-rules && sudo udevadm trigger"
    fi
  else
    echo "    ⚠ brak sudo w PATH"
  fi
fi

# ── Natychmiastowe uprawnienia na już podpiętym urządzeniu ────────────────
echo ""
echo "==> chmod bieżącego węzła USB (8888:1719)"
if lsusb -d 8888:1719 >/dev/null 2>&1; then
  if "$APP_DIR/fix-usb-perms.sh"; then
    echo "    uprawnienia OK"
  else
    echo "    ⚠ fix-usb-perms nie powiódł się — odłącz/podepnij DSP po udev"
  fi
else
  echo "    (urządzenie nie podpięte — podepnij i uruchom: $APP_DIR/fix-usb-perms.sh)"
fi

# ── Start daemona ─────────────────────────────────────────────────────────
echo ""
echo "==> Start mvsilicon-acpd"
systemctl --user restart mvsilicon-acpd.service || true
sleep 1
systemctl --user --no-pager -l status mvsilicon-acpd.service || true

echo ""
echo "────────────────────────────────────────────────────────"
echo " Gotowe. Jeśli nadal Access denied:"
echo "   1) odłącz i podepnij DSP"
echo "   2) $APP_DIR/fix-usb-perms.sh"
echo "   3) systemctl --user restart mvsilicon-acpd"
echo ""
echo " Extension:"
echo "   gnome-extensions enable $EXT_UUID"
echo " Test D-Bus:"
echo "   busctl --user call org.mvsilicon.Acp /org/mvsilicon/Acp1 org.mvsilicon.Acp1 IsConnected"
echo "────────────────────────────────────────────────────────"
