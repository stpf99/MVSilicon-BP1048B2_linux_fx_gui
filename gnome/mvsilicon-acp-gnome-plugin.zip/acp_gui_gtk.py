#!/usr/bin/env python3
"""
acp_gui_gtk.py — pełny edytor FX dla MVSilicon BP1048B2 (GTK4 / libadwaita)
Komunikuje się wyłącznie z acpd przez D-Bus (org.mvsilicon.Acp) —
nie otwiera USB samodzielnie (brak konfliktu z apletem GNOME).

Wymagania:
    sudo apt install python3-gi gir1.2-gtk-4.0 gir1.2-adw-1
"""
from __future__ import annotations

import json
import sys
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gio", "2.0")
gi.require_version("GLib", "2.0")
from gi.repository import Gtk, Adw, Gio, GLib

BUS_NAME = "org.mvsilicon.Acp"
OBJ_PATH = "/org/mvsilicon/Acp1"
IFACE = "org.mvsilicon.Acp1"

# Klucze UI → etykieta, min, max (dla switch: min=max=None)
MIC_CONTROLS = [
    ("mic_ns_en", "Noise Suppress", None, None),
    ("mic_ns_thr", "NS próg", -9999, 0),
    ("mic_ns_ratio", "NS ratio", 1, 10),
    ("mic_howl_en", "Howling", None, None),
    ("mic_howl_mode", "Howl mode", 1, 3),
    ("mic_freq_en", "Freq Shift", None, None),
    ("mic_freq_delta", "Delta-F", -100, 100),
    ("mic_silence_en", "Silence detect", None, None),
    ("mic_echo_en", "Echo", None, None),
    ("mic_echo_cf", "Echo cutoff", 100, 16000),
    ("mic_echo_att", "Echo atten", 0, 65535),
    ("mic_echo_delay", "Echo delay", 10, 500),
    ("mic_echo_dry", "Echo dry", 0, 100),
    ("mic_echo_wet", "Echo wet", 0, 100),
    ("mic_rev_en", "Reverb room", None, None),
    ("mic_rev_wet", "Rev wet", 0, 100),
    ("mic_rev_room", "Room size", 0, 100),
    ("mic_rev_damp", "Damping", 0, 100),
    ("mic_plate_en", "Plate reverb", None, None),
    ("mic_plate_decay", "Plate decay", 0, 100),
    ("mic_plate_wet", "Plate wet", 0, 100),
    ("mic_plate_pre", "Pre-delay", 0, 5000),
    ("mic_pitch_en", "Pitch", None, None),
    ("mic_pitch_key", "Pitch key", 30, 90),
    ("mic_autotune_en", "Auto Tune", None, None),
    ("mic_autotune_key", "AT key", 30, 110),
    ("mic_autotune_snap", "AT snap", 0, 200),
    ("mic_vch_en", "Voice changer", None, None),
    ("mic_vch_pitch", "VC pitch", 50, 400),
    ("mic_vch_formant", "VC formant", 50, 200),
    ("mic_drc_en", "Mic DRC", None, None),
    ("mic_drc_thr1", "DRC thr1", -9999, 0),
    ("mic_drc_ratio1", "DRC ratio1", 1, 200),
]

MUS_CONTROLS = [
    ("mus_ns_en", "Noise Suppress", None, None),
    ("mus_ns_thr", "NS próg", -9999, 0),
    ("mus_vbass_en", "Virtual Bass", None, None),
    ("mus_vbass_cut", "Bass cutoff", 20, 300),
    ("mus_vbass_int", "Bass intensity", 0, 100),
    ("mus_vbass_enh", "Bass enhanced", None, None),
    ("mus_vbass_cls_en", "Bass classic", None, None),
    ("mus_3d_en", "3D Surround", None, None),
    ("mus_3d_int", "3D intensity", 0, 100),
    ("mus_3dplus_en", "3D Plus", None, None),
    ("mus_3dplus_int", "3D+ intensity", 0, 100),
    ("mus_stereo_en", "Stereo widener", None, None),
    ("mus_stereo_shp", "Stereo shape", 1, 3),
    ("mus_vcut_en", "Voice Cut", None, None),
    ("mus_vcut_val", "VCut mix %", 0, 100),
    ("mus_vrem_en", "Voice Remove", None, None),
    ("mus_vrem_lo", "VR low", 20, 2000),
    ("mus_vrem_hi", "VR high", 5000, 20000),
    ("mus_pitch_en", "Pitch", None, None),
    ("mus_pitch_key", "Pitch key", 30, 110),
    ("mus_drc_en", "Music DRC", None, None),
    ("mus_drc_xfreq", "DRC xover", 20, 2000),
    ("mus_delay_en", "PCM Delay", None, None),
    ("mus_delay_val", "Delay ms", 0, 500),
    ("mus_exciter_en", "Exciter", None, None),
    ("mus_exciter_cut", "Exc cutoff", 200, 16000),
    ("mus_phase_en", "Phase shift", None, None),
]

GAIN_CONTROLS = [
    ("gain_mus", "Music Out", 0, 8192),
    ("gain_mic", "Mic Out", 0, 8192),
    ("gain_mic_bypass", "Mic Bypass", 0, 8192),
    ("gain_mic_echo", "Mic Echo", 0, 8192),
    ("gain_mic_rev", "Mic Reverb", 0, 8192),
    ("gain_bt", "Bluetooth In", 0, 8192),
    ("gain_usb", "USB Card", 0, 8192),
    ("gain_i2s", "I2S In", 0, 8192),
    ("gain_spdif", "SPDIF In", 0, 8192),
]


class AcpClient:
    def __init__(self):
        self.proxy = None
        self.state = {}
        self.connected = False
        self.on_state = None
        self.on_connected = None

    def connect(self):
        try:
            self.proxy = Gio.DBusProxy.new_for_bus_sync(
                Gio.BusType.SESSION,
                Gio.DBusProxyFlags.NONE,
                None,
                BUS_NAME,
                OBJ_PATH,
                IFACE,
                None,
            )
            self.proxy.connect("g-signal", self._on_signal)
            self.refresh()
            try:
                self.proxy.call_sync("Connect", None, Gio.DBusCallFlags.NONE, 3000, None)
            except Exception:
                pass
            return True
        except Exception as e:
            print(f"[acp_gui_gtk] D-Bus: {e}", file=sys.stderr)
            return False

    def _on_signal(self, proxy, sender, signal, params):
        if signal == "StateChanged":
            (json_s,) = params.unpack()
            try:
                self.state = json.loads(json_s)
            except Exception:
                return
            if self.on_state:
                GLib.idle_add(self.on_state, self.state)
        elif signal == "ConnectedChanged":
            (c,) = params.unpack()
            self.connected = bool(c)
            if self.on_connected:
                GLib.idle_add(self.on_connected, self.connected)

    def refresh(self):
        if not self.proxy:
            return
        try:
            res = self.proxy.call_sync("GetState", None, Gio.DBusCallFlags.NONE, 2000, None)
            (json_s,) = res.unpack()
            self.state = json.loads(json_s)
        except Exception as e:
            print(f"[acp_gui_gtk] GetState: {e}", file=sys.stderr)
        try:
            res = self.proxy.call_sync("IsConnected", None, Gio.DBusCallFlags.NONE, 1000, None)
            (c,) = res.unpack()
            self.connected = bool(c)
        except Exception:
            self.connected = False

    def set_param(self, key: str, value: int) -> bool:
        if not self.proxy:
            return False
        try:
            res = self.proxy.call_sync(
                "SetParam",
                GLib.Variant("(si)", (key, int(value))),
                Gio.DBusCallFlags.NONE,
                2000,
                None,
            )
            (ok,) = res.unpack()
            self.state[key] = int(value)
            return bool(ok)
        except Exception as e:
            print(f"[acp_gui_gtk] SetParam {key}: {e}", file=sys.stderr)
            return False

    def list_presets(self):
        if not self.proxy:
            return []
        try:
            res = self.proxy.call_sync("ListPresets", None, Gio.DBusCallFlags.NONE, 2000, None)
            (names,) = res.unpack()
            return list(names)
        except Exception:
            return []

    def load_preset(self, name: str) -> bool:
        if not self.proxy:
            return False
        try:
            res = self.proxy.call_sync(
                "LoadPreset",
                GLib.Variant("(s)", (name,)),
                Gio.DBusCallFlags.NONE,
                3000,
                None,
            )
            (ok,) = res.unpack()
            if ok:
                self.refresh()
            return bool(ok)
        except Exception:
            return False

    def save_flash(self) -> bool:
        if not self.proxy:
            return False
        try:
            res = self.proxy.call_sync("SaveFlash", None, Gio.DBusCallFlags.NONE, 3000, None)
            (ok,) = res.unpack()
            return bool(ok)
        except Exception:
            return False


class ControlRow(Gtk.Box):
    """Jedna kontrolka: switch lub scale + label."""

    def __init__(self, key, label, vmin, vmax, client: AcpClient):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.key = key
        self.client = client
        self._suppress = False
        self.set_margin_start(8)
        self.set_margin_end(8)
        self.set_margin_top(2)
        self.set_margin_bottom(2)

        lbl = Gtk.Label(label=label, xalign=0, hexpand=True)
        self.append(lbl)

        if vmin is None:
            self.widget = Gtk.Switch()
            self.widget.set_valign(Gtk.Align.CENTER)
            self.widget.connect("notify::active", self._on_switch)
        else:
            self.widget = Gtk.Scale.new_with_range(
                Gtk.Orientation.HORIZONTAL, vmin, vmax, 1
            )
            self.widget.set_hexpand(True)
            self.widget.set_draw_value(True)
            self.widget.set_value_pos(Gtk.PositionType.RIGHT)
            self.widget.set_size_request(180, -1)
            self.widget.connect("value-changed", self._on_scale)
        self.append(self.widget)

    def _on_switch(self, *a):
        if self._suppress:
            return
        self.client.set_param(self.key, 1 if self.widget.get_active() else 0)

    def _on_scale(self, *a):
        if self._suppress:
            return
        self.client.set_param(self.key, int(self.widget.get_value()))

    def apply_value(self, v):
        self._suppress = True
        if isinstance(self.widget, Gtk.Switch):
            self.widget.set_active(bool(v))
        else:
            self.widget.set_value(float(v))
        self._suppress = False


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app, client: AcpClient):
        super().__init__(application=app, title="ACP DSP — MVSilicon BP1048B2")
        self.client = client
        self.rows: dict[str, ControlRow] = {}
        self.set_default_size(720, 780)

        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar()
        self.status = Gtk.Label(label="…")
        header.set_title_widget(self.status)
        toolbar.add_top_bar(header)

        # Top actions
        box_top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box_top.set_margin_start(12)
        box_top.set_margin_end(12)
        box_top.set_margin_top(8)
        box_top.set_margin_bottom(4)

        self.preset_dd = Gtk.DropDown()
        self.preset_dd.set_hexpand(True)
        box_top.append(self.preset_dd)

        btn_load = Gtk.Button(label="Załaduj")
        btn_load.connect("clicked", self._on_load_preset)
        box_top.append(btn_load)

        btn_flash = Gtk.Button(label="Zapisz flash")
        btn_flash.add_css_class("suggested-action")
        btn_flash.connect("clicked", self._on_save_flash)
        box_top.append(btn_flash)

        btn_ref = Gtk.Button(icon_name="view-refresh-symbolic")
        btn_ref.connect("clicked", lambda *_: self._full_refresh())
        box_top.append(btn_ref)

        # Notebook
        nb = Gtk.Notebook()
        nb.append_page(self._build_page(MIC_CONTROLS), Gtk.Label(label="🎤 Mikrofon"))
        nb.append_page(self._build_page(MUS_CONTROLS), Gtk.Label(label="🎵 Muzyka"))
        nb.append_page(self._build_page(GAIN_CONTROLS), Gtk.Label(label="🔊 Gain"))

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.append(box_top)
        outer.append(nb)
        toolbar.set_content(outer)
        self.set_content(toolbar)

        client.on_state = self._on_state
        client.on_connected = self._on_connected
        self._full_refresh()

    def _build_page(self, controls):
        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.set_margin_top(8)
        box.set_margin_bottom(8)
        for key, label, vmin, vmax in controls:
            row = ControlRow(key, label, vmin, vmax, self.client)
            self.rows[key] = row
            box.append(row)
        scroll.set_child(box)
        return scroll

    def _full_refresh(self):
        self.client.refresh()
        self._on_connected(self.client.connected)
        self._on_state(self.client.state)
        names = self.client.list_presets()
        model = Gtk.StringList.new(names if names else ["(brak)"])
        self.preset_dd.set_model(model)

    def _on_state(self, state: dict):
        for key, row in self.rows.items():
            if key in state:
                row.apply_value(state[key])
        return False

    def _on_connected(self, c: bool):
        self.status.set_text("✔ BP1048B2 połączone" if c else "✗ DSP rozłączone / acpd offline")
        return False

    def _on_load_preset(self, *_a):
        model = self.preset_dd.get_model()
        if not model:
            return
        idx = self.preset_dd.get_selected()
        if idx < 0:
            return
        name = model.get_string(idx)
        if name.startswith("("):
            return
        ok = self.client.load_preset(name)
        self._on_state(self.client.state)
        self.status.set_text(f"Preset: {name}" if ok else "Błąd presetu")

    def _on_save_flash(self, *_a):
        ok = self.client.save_flash()
        self.status.set_text("Zapisano do flash" if ok else "Błąd zapisu flash")


class App(Adw.Application):
    def __init__(self):
        super().__init__(application_id="org.mvsilicon.AcpGui")
        self.client = AcpClient()

    def do_activate(self):
        if not self.client.connect():
            dialog = Adw.MessageDialog(
                heading="acpd niedostępny",
                body="Uruchom daemon:\n  systemctl --user start mvsilicon-acpd\nlub:\n  python3 acpd.py",
                transient_for=None,
            )
            dialog.add_response("ok", "OK")
            dialog.present()
        win = MainWindow(self, self.client)
        win.present()


def main():
    app = App()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main() or 0)
