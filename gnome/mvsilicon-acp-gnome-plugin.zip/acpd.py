#!/usr/bin/env python3
"""
acpd.py — MVSilicon BP1048B2 ACP daemon
=========================================
Jedyny proces trzymający otwarte połączenie USB (iface 4 / HID) do DSP.
Wystawia usługę D-Bus na session bus: org.mvsilicon.Acp1
(/org/mvsilicon/Acp1), z której korzysta:
  - aplet GNOME Shell (tryb prosty, w panelu)
  - pełny edytor acp_gui_qt2.py (tryb rozbudowany / floating window)

Dzięki temu oba UI mogą działać jednocześnie bez bicia się o urządzenie —
pełny edytor, gdy chce przejąć wyłączność (np. do surowego sniffowania),
woła RequestLock() i daemon oddaje mu USB na czas trwania locka.

Wymaga: PyGObject (python3-gi), pyusb.
    sudo apt install python3-gi gir1.2-glib-2.0
    pip install pyusb --break-system-packages
    sudo chmod a+rw /dev/bus/usb/*/*   (albo reguła udev, patrz README)

Uruchomienie ręczne (test):
    python3 acpd.py --foreground

Docelowo: przez D-Bus service activation (org.mvsilicon.Acp.service) albo
systemd --user unit (mvsilicon-acpd.service) — patrz katalog install/.
"""
import os
import sys
import json
import time
import copy
import struct
import signal
import threading

import gi
gi.require_version("GLib", "2.0")
gi.require_version("Gio", "2.0")
from gi.repository import GLib, Gio

try:
    import usb.core as _usb_core
    import usb.util as _usb_util
    _HAS_PYUSB = True
except ImportError:
    _usb_core = None
    _usb_util = None
    _HAS_PYUSB = False


# ─────────────────────────────────────────────────────────────────────────
# Protokół ACP (skopiowane 1:1 z acp_gui_qt2.py — patrz tamten plik po pełny
# opis; jeśli firmware/ID modułów się zmienią, aktualizuj OBA miejsca albo
# w przyszłości wydziel do wspólnego pakietu `acp_protocol.py`)
# ─────────────────────────────────────────────────────────────────────────

VID, PID = 0x8888, 0x1719
SYNC_HEAD = bytes([0xA5, 0x5A])
SYNC_TAIL = 0x16
ALL_PARAM = 0xFF

MODULE = {
    "FIRMWARE": 0x00, "SYSTEM": 0x01,
    "PGA0": 0x03, "ADC0": 0x04, "PGA1": 0x06, "ADC1": 0x07,
    "AGC1": 0x08, "DAC0": 0x09, "DAC1": 0x0A,
    "I2S0": 0x0B, "I2S1": 0x0C, "SPDIF": 0x0D,
    "USER_TAG": 0xFC, "SAVE_FLASH": 0xFD,
    "MUSIC_NOISE": 0x81, "MUSIC_PITCH": 0x94, "MUSIC_VCUT": 0x95,
    "MUSIC_VREMOVE": 0x96, "MUSIC_3D": 0x97, "MUSIC_3DPLUS": 0x98,
    "MUSIC_VBASS": 0x99, "MUSIC_VBASS_CLS": 0x9A, "MUSIC_STEREO": 0x9B,
    "MUSIC_DELAY": 0x9C, "MUSIC_EXCITER": 0x9D, "MUSIC_PHASE": 0x9E,
    "MUSIC_DRC": 0x9F, "MUSIC_PRE_EQ": 0xA2, "MUSIC_OUT_EQ": 0xA3,
    "MUSIC_OUT_GAIN": 0xAC, "I2S_IN_GAIN": 0xB8, "BT_IN_GAIN": 0xB9,
    "USB_CARD_GAIN": 0xBA, "SPDIF_IN_GAIN": 0xBB,
    "MIC_NOISE_SUP": 0x82, "MIC_FREQ_SHIFT": 0x83, "MIC_HOWLING": 0x84,
    "MIC_PITCH": 0x86, "MIC_AUTOTUNE": 0x87, "MIC_VCHANGER": 0x88,
    "MIC_VCHANGER_PRO": 0x89, "MIC_ECHO": 0x8A, "MIC_REVERB": 0x8B,
    "MIC_PLATE_REV": 0x8C, "MIC_PRO_REVERB": 0x8D, "MIC_SILENCE": 0x91,
    "MIC_DRC": 0xA0, "MIC_PRE_EQ": 0xA4, "MIC_BYPASS_EQ": 0xA5,
    "MIC_ECHO_EQ": 0xA6, "MIC_REVERB_EQ": 0xA7, "MIC_OUT_EQ": 0xA8,
    "MIC_BYPASS_GAIN": 0xAD, "MIC_ECHO_GAIN": 0xAE, "MIC_REVERB_GAIN": 0xAF,
    "MIC_OUT_GAIN": 0xB0,
    "GUITAR_PINGPONG": 0x8E, "GUITAR_CHORUS": 0x8F, "GUITAR_AUTOWAH": 0x90,
    "REC_DRC": 0xA1, "REC_OUT_EQ": 0xA9, "REC_BYPASS_GAIN": 0xB1,
    "REC_EFFECT_GAIN": 0xB2, "REC_MUSIC_GAIN": 0xB3,
    "REC_EFFECT_REMIND": 0xB4, "USB_OUT_GAIN": 0xB5,
    "KEY_REMIND_GAIN": 0xB6, "EFFECT_REMIND_GAIN": 0xB7,
}


def build_frame(module_id, params, param_select=ALL_PARAM):
    data = bytes([param_select]) + params
    return SYNC_HEAD + bytes([module_id, len(data)]) + data + bytes([SYNC_TAIL])


def u16(values):
    return b"".join(struct.pack("<H", v & 0xFFFF) for v in values)


# Mapowanie widget-key -> (module_id, [kolejność kluczy w module])
MIC_MODULES = {
    "mic_ns":    (MODULE["MIC_NOISE_SUP"],  ["mic_ns_en", "mic_ns_thr", "mic_ns_ratio", "mic_ns_attack", "mic_ns_release"]),
    "mic_howl":  (MODULE["MIC_HOWLING"],    ["mic_howl_en", "mic_howl_mode"]),
    "mic_freq":  (MODULE["MIC_FREQ_SHIFT"], ["mic_freq_en", "mic_freq_delta"]),
    "mic_sil":   (MODULE["MIC_SILENCE"],    ["mic_silence_en", "mic_silence_amp"]),
    "mic_echo":  (MODULE["MIC_ECHO"],       ["mic_echo_en", "mic_echo_cf", "mic_echo_att", "mic_echo_delay", "mic_echo_max_delay", "mic_echo_hq", "mic_echo_dry", "mic_echo_wet"]),
    "mic_rev":   (MODULE["MIC_REVERB"],     ["mic_rev_en", "mic_rev_dry", "mic_rev_wet", "mic_rev_width", "mic_rev_room", "mic_rev_damp"]),
    "mic_plate": (MODULE["MIC_PLATE_REV"],  ["mic_plate_en", "mic_plate_hcf", "mic_plate_mod", "mic_plate_pre", "mic_plate_diff", "mic_plate_decay", "mic_plate_damp", "mic_plate_wet"]),
    "mic_pitch": (MODULE["MIC_PITCH"],      ["mic_pitch_en", "mic_pitch_key"]),
    "mic_at":    (MODULE["MIC_AUTOTUNE"],   ["mic_autotune_en", "mic_autotune_key", "mic_autotune_snap", "mic_autotune_acc"]),
    "mic_vch":   (MODULE["MIC_VCHANGER"],   ["mic_vch_en", "mic_vch_pitch", "mic_vch_formant"]),
    "mic_drc":   (MODULE["MIC_DRC"],        ["mic_drc_en", "mic_drc_thr1", "mic_drc_thr2", "mic_drc_ratio1", "mic_drc_ratio2", "mic_drc_att", "mic_drc_rel"]),
}

MUS_MODULES = {
    "mus_ns":      (MODULE["MUSIC_NOISE"],     ["mus_ns_en", "mus_ns_thr", "mus_ns_ratio", "mus_ns_attack", "mus_ns_release"]),
    "mus_vbass":   (MODULE["MUSIC_VBASS"],     ["mus_vbass_en", "mus_vbass_cut", "mus_vbass_int", "mus_vbass_enh"]),
    "mus_vbcls":   (MODULE["MUSIC_VBASS_CLS"], ["mus_vbass_cls_en", "mus_vbass_cls_cut", "mus_vbass_cls_int"]),
    "mus_3d":      (MODULE["MUSIC_3D"],        ["mus_3d_en", "mus_3d_int"]),
    "mus_3dp":     (MODULE["MUSIC_3DPLUS"],    ["mus_3dplus_en", "mus_3dplus_int"]),
    "mus_stereo":  (MODULE["MUSIC_STEREO"],    ["mus_stereo_en", "mus_stereo_shp"]),
    "mus_vcut":    (MODULE["MUSIC_VCUT"],      ["mus_vcut_en", "mus_vcut_val"]),
    "mus_vrem":    (MODULE["MUSIC_VREMOVE"],   ["mus_vrem_en", "mus_vrem_lo", "mus_vrem_hi"]),
    "mus_pitch":   (MODULE["MUSIC_PITCH"],     ["mus_pitch_en", "mus_pitch_key"]),
    "mus_drc":     (MODULE["MUSIC_DRC"],       ["mus_drc_en", "mus_drc_xfreq", "mus_drc_thr1", "mus_drc_thr2", "mus_drc_ratio1", "mus_drc_ratio2", "mus_drc_att1", "mus_drc_rel"]),
    "mus_delay":   (MODULE["MUSIC_DELAY"],     ["mus_delay_en", "mus_delay_val"]),
    "mus_exciter": (MODULE["MUSIC_EXCITER"],   ["mus_exciter_en", "mus_exciter_cut", "mus_exciter_dry", "mus_exciter_wet"]),
    "mus_phase":   (MODULE["MUSIC_PHASE"],     ["mus_phase_en", "mus_phase_diff"]),
}

GAIN_MODULES = {
    "gain_mus":        (MODULE["MUSIC_OUT_GAIN"], "Music Out Gain"),
    "gain_mic":        (MODULE["MIC_OUT_GAIN"],    "Mic Out Gain"),
    "gain_mic_bypass": (MODULE["MIC_BYPASS_GAIN"], "Mic Bypass Gain"),
    "gain_mic_echo":   (MODULE["MIC_ECHO_GAIN"],   "Mic Echo Gain"),
    "gain_mic_rev":    (MODULE["MIC_REVERB_GAIN"], "Mic Reverb Gain"),
    "gain_bt":         (MODULE["BT_IN_GAIN"],      "BT In Gain"),
    "gain_usb":        (MODULE["USB_CARD_GAIN"],   "USB Card Gain"),
    "gain_i2s":        (MODULE["I2S_IN_GAIN"],     "I2S In Gain"),
    "gain_spdif":      (MODULE["SPDIF_IN_GAIN"],   "SPDIF In Gain"),
}

KEY_TO_MODULE = {}
for _mod_name, (_mod_id, _keys) in {**MIC_MODULES, **MUS_MODULES}.items():
    for _k in _keys:
        KEY_TO_MODULE[_k] = _mod_name
for _gkey in GAIN_MODULES:
    KEY_TO_MODULE[_gkey] = f"__gain__{_gkey}"

DEFAULT_STATE = {
    "mic_ns_en": 1, "mic_ns_thr": -4500, "mic_ns_ratio": 3, "mic_ns_attack": 2, "mic_ns_release": 100,
    "mic_howl_en": 0, "mic_howl_mode": 1,
    "mic_freq_en": 0, "mic_freq_delta": 2,
    "mic_silence_en": 1, "mic_silence_amp": 0,
    "mic_echo_en": 0, "mic_echo_cf": 8000, "mic_echo_att": 14636, "mic_echo_delay": 256,
    "mic_echo_max_delay": 350, "mic_echo_hq": 0, "mic_echo_dry": 100, "mic_echo_wet": 100,
    "mic_rev_en": 0, "mic_rev_dry": 100, "mic_rev_wet": 100, "mic_rev_width": 100, "mic_rev_room": 65, "mic_rev_damp": 35,
    "mic_plate_en": 0, "mic_plate_hcf": 8000, "mic_plate_mod": 1, "mic_plate_pre": 2500,
    "mic_plate_diff": 60, "mic_plate_decay": 65, "mic_plate_damp": 5000, "mic_plate_wet": 55,
    "mic_pitch_en": 0, "mic_pitch_key": 70,
    "mic_autotune_en": 0, "mic_autotune_key": 67, "mic_autotune_snap": 110, "mic_autotune_acc": 0,
    "mic_vch_en": 0, "mic_vch_pitch": 200, "mic_vch_formant": 150,
    "mic_drc_en": 0, "mic_drc_thr1": 0, "mic_drc_thr2": 0, "mic_drc_ratio1": 100, "mic_drc_ratio2": 100, "mic_drc_att": 1, "mic_drc_rel": 1000,
    "mus_ns_en": 0, "mus_ns_thr": -6500, "mus_ns_ratio": 2, "mus_ns_attack": 1, "mus_ns_release": 100,
    "mus_vbass_en": 1, "mus_vbass_cut": 80, "mus_vbass_int": 7, "mus_vbass_enh": 1,
    "mus_vbass_cls_en": 0, "mus_vbass_cls_cut": 50, "mus_vbass_cls_int": 12,
    "mus_3d_en": 0, "mus_3d_int": 80, "mus_3dplus_en": 0, "mus_3dplus_int": 70,
    "mus_stereo_en": 1, "mus_stereo_shp": 1,
    "mus_vcut_en": 0, "mus_vcut_val": 100,
    "mus_vrem_en": 0, "mus_vrem_lo": 200, "mus_vrem_hi": 15000,
    "mus_pitch_en": 0, "mus_pitch_key": 70,
    "mus_drc_en": 1, "mus_drc_xfreq": 300, "mus_drc_thr1": 0, "mus_drc_thr2": 0, "mus_drc_ratio1": 100, "mus_drc_ratio2": 100, "mus_drc_att1": 1, "mus_drc_rel": 1000,
    "mus_delay_en": 0, "mus_delay_val": 10,
    "mus_exciter_en": 0, "mus_exciter_cut": 1000, "mus_exciter_dry": 100, "mus_exciter_wet": 100,
    "mus_phase_en": 0, "mus_phase_diff": 1,
    "gain_mus": 4096, "gain_mic": 4096, "gain_mic_bypass": 4096, "gain_mic_echo": 4096, "gain_mic_rev": 4096,
    "gain_bt": 4096, "gain_usb": 4096, "gain_i2s": 4096, "gain_spdif": 4096,
}

CONFIG_DIR = os.environ.get("ACPD_CONFIG_DIR", os.path.expanduser("~/.config/mvsilicon-acp"))
PRESETS_PATH = os.path.join(CONFIG_DIR, "presets.json")
STATE_PATH = os.path.join(CONFIG_DIR, "last_state.json")

DEFAULT_PRESETS = {
    'Default (DAM)': {
        'mic_ns_en': 1,
        'mic_ns_thr': -4500,
        'mic_ns_ratio': 3,
        'mic_ns_attack': 2,
        'mic_ns_release': 100,
        'mic_howl_en': 0,
        'mic_howl_mode': 1,
        'mic_freq_en': 0,
        'mic_freq_delta': 2,
        'mic_silence_en': 1,
        'mic_silence_amp': 0,
        'mic_echo_en': 0,
        'mic_echo_cf': 8000,
        'mic_echo_att': 14636,
        'mic_echo_delay': 256,
        'mic_echo_max_delay': 350,
        'mic_echo_hq': 0,
        'mic_echo_dry': 100,
        'mic_echo_wet': 100,
        'mic_rev_en': 0,
        'mic_rev_dry': 100,
        'mic_rev_wet': 100,
        'mic_rev_width': 100,
        'mic_rev_room': 65,
        'mic_rev_damp': 35,
        'mic_plate_en': 0,
        'mic_plate_hcf': 8000,
        'mic_plate_mod': 1,
        'mic_plate_pre': 2500,
        'mic_plate_diff': 60,
        'mic_plate_decay': 65,
        'mic_plate_damp': 5000,
        'mic_plate_wet': 55,
        'mic_pitch_en': 0,
        'mic_pitch_key': 70,
        'mic_autotune_en': 0,
        'mic_autotune_key': 67,
        'mic_autotune_snap': 110,
        'mic_autotune_acc': 0,
        'mic_vch_en': 0,
        'mic_vch_pitch': 200,
        'mic_vch_formant': 150,
        'mic_drc_en': 0,
        'mic_drc_thr1': 0,
        'mic_drc_thr2': 0,
        'mic_drc_ratio1': 100,
        'mic_drc_ratio2': 100,
        'mic_drc_att': 1,
        'mic_drc_rel': 1000,
        'mus_ns_en': 0,
        'mus_ns_thr': -6500,
        'mus_ns_ratio': 2,
        'mus_ns_attack': 1,
        'mus_ns_release': 100,
        'mus_vbass_en': 1,
        'mus_vbass_cut': 80,
        'mus_vbass_int': 7,
        'mus_vbass_enh': 1,
        'mus_vbass_cls_en': 0,
        'mus_vbass_cls_cut': 50,
        'mus_vbass_cls_int': 12,
        'mus_3d_en': 0,
        'mus_3d_int': 80,
        'mus_3dplus_en': 0,
        'mus_3dplus_int': 70,
        'mus_stereo_en': 1,
        'mus_stereo_shp': 1,
        'mus_vcut_en': 0,
        'mus_vcut_val': 100,
        'mus_vrem_en': 0,
        'mus_vrem_lo': 200,
        'mus_vrem_hi': 15000,
        'mus_pitch_en': 0,
        'mus_pitch_key': 70,
        'mus_drc_en': 1,
        'mus_drc_xfreq': 300,
        'mus_drc_thr1': 0,
        'mus_drc_thr2': 0,
        'mus_drc_ratio1': 100,
        'mus_drc_ratio2': 100,
        'mus_drc_att1': 1,
        'mus_drc_rel': 1000,
        'mus_delay_en': 0,
        'mus_delay_val': 10,
        'mus_exciter_en': 0,
        'mus_exciter_cut': 1000,
        'mus_exciter_dry': 100,
        'mus_exciter_wet': 100,
        'mus_phase_en': 0,
        'mus_phase_diff': 1,
        'gain_mus': 4096,
        'gain_mic': 4096,
        'gain_mic_bypass': 4096,
        'gain_mic_echo': 4096,
        'gain_mic_rev': 4096,
        'gain_bt': 4096,
        'gain_usb': 4096,
        'gain_i2s': 4096,
        'gain_spdif': 4096,
    },
    'Karaoke': {
        'mic_ns_en': 1,
        'mic_ns_thr': -3000,
        'mic_ns_ratio': 4,
        'mic_ns_attack': 2,
        'mic_ns_release': 100,
        'mic_howl_en': 1,
        'mic_howl_mode': 2,
        'mic_freq_en': 0,
        'mic_freq_delta': 0,
        'mic_silence_en': 1,
        'mic_silence_amp': 0,
        'mic_echo_en': 1,
        'mic_echo_cf': 8000,
        'mic_echo_att': 12000,
        'mic_echo_delay': 180,
        'mic_echo_max_delay': 350,
        'mic_echo_hq': 0,
        'mic_echo_dry': 100,
        'mic_echo_wet': 100,
        'mic_rev_en': 0,
        'mic_rev_dry': 100,
        'mic_rev_wet': 40,
        'mic_rev_width': 80,
        'mic_rev_room': 50,
        'mic_rev_damp': 40,
        'mic_plate_en': 1,
        'mic_plate_hcf': 8000,
        'mic_plate_mod': 1,
        'mic_plate_pre': 2000,
        'mic_plate_diff': 60,
        'mic_plate_decay': 70,
        'mic_plate_damp': 5000,
        'mic_plate_wet': 65,
        'mic_pitch_en': 0,
        'mic_pitch_key': 70,
        'mic_autotune_en': 1,
        'mic_autotune_key': 98,
        'mic_autotune_snap': 117,
        'mic_autotune_acc': 0,
        'mic_vch_en': 0,
        'mic_vch_pitch': 200,
        'mic_vch_formant': 150,
        'mic_drc_en': 1,
        'mic_drc_thr1': -2000,
        'mic_drc_thr2': -1000,
        'mic_drc_ratio1': 4,
        'mic_drc_ratio2': 3,
        'mic_drc_att': 4,
        'mic_drc_rel': 500,
        'mus_ns_en': 1,
        'mus_ns_thr': -6000,
        'mus_ns_ratio': 2,
        'mus_ns_attack': 1,
        'mus_ns_release': 100,
        'mus_vbass_en': 1,
        'mus_vbass_cut': 80,
        'mus_vbass_int': 20,
        'mus_vbass_enh': 1,
        'mus_vbass_cls_en': 0,
        'mus_vbass_cls_cut': 50,
        'mus_vbass_cls_int': 12,
        'mus_3d_en': 1,
        'mus_3d_int': 60,
        'mus_3dplus_en': 0,
        'mus_3dplus_int': 50,
        'mus_stereo_en': 1,
        'mus_stereo_shp': 1,
        'mus_vcut_en': 1,
        'mus_vcut_val': 80,
        'mus_vrem_en': 0,
        'mus_vrem_lo': 200,
        'mus_vrem_hi': 15000,
        'mus_pitch_en': 0,
        'mus_pitch_key': 70,
        'mus_drc_en': 1,
        'mus_drc_xfreq': 300,
        'mus_drc_thr1': 0,
        'mus_drc_thr2': 0,
        'mus_drc_ratio1': 100,
        'mus_drc_ratio2': 100,
        'mus_drc_att1': 1,
        'mus_drc_rel': 1000,
        'mus_delay_en': 0,
        'mus_delay_val': 50,
        'mus_exciter_en': 0,
        'mus_exciter_cut': 1000,
        'mus_exciter_dry': 100,
        'mus_exciter_wet': 100,
        'mus_phase_en': 0,
        'mus_phase_diff': 0,
        'gain_mus': 4096,
        'gain_mic': 4096,
        'gain_mic_bypass': 3000,
        'gain_mic_echo': 4096,
        'gain_mic_rev': 3500,
        'gain_bt': 4096,
        'gain_usb': 4096,
        'gain_i2s': 4096,
        'gain_spdif': 4096,
    },
    'Studio Vocal': {
        'mic_ns_en': 1,
        'mic_ns_thr': -5000,
        'mic_ns_ratio': 3,
        'mic_ns_attack': 2,
        'mic_ns_release': 100,
        'mic_howl_en': 1,
        'mic_howl_mode': 2,
        'mic_freq_en': 0,
        'mic_freq_delta': 0,
        'mic_silence_en': 1,
        'mic_silence_amp': 0,
        'mic_echo_en': 0,
        'mic_echo_cf': 8000,
        'mic_echo_att': 8000,
        'mic_echo_delay': 120,
        'mic_echo_max_delay': 350,
        'mic_echo_hq': 0,
        'mic_echo_dry': 100,
        'mic_echo_wet': 100,
        'mic_rev_en': 0,
        'mic_rev_dry': 100,
        'mic_rev_wet': 30,
        'mic_rev_width': 80,
        'mic_rev_room': 40,
        'mic_rev_damp': 40,
        'mic_plate_en': 1,
        'mic_plate_hcf': 10000,
        'mic_plate_mod': 1,
        'mic_plate_pre': 1000,
        'mic_plate_diff': 70,
        'mic_plate_decay': 45,
        'mic_plate_damp': 6000,
        'mic_plate_wet': 30,
        'mic_pitch_en': 0,
        'mic_pitch_key': 70,
        'mic_autotune_en': 0,
        'mic_autotune_key': 67,
        'mic_autotune_snap': 110,
        'mic_autotune_acc': 0,
        'mic_vch_en': 0,
        'mic_vch_pitch': 200,
        'mic_vch_formant': 150,
        'mic_drc_en': 1,
        'mic_drc_thr1': -3000,
        'mic_drc_thr2': -1500,
        'mic_drc_ratio1': 3,
        'mic_drc_ratio2': 2,
        'mic_drc_att': 3,
        'mic_drc_rel': 300,
        'mus_ns_en': 1,
        'mus_ns_thr': -7000,
        'mus_ns_ratio': 2,
        'mus_ns_attack': 1,
        'mus_ns_release': 100,
        'mus_vbass_en': 0,
        'mus_vbass_cut': 80,
        'mus_vbass_int': 7,
        'mus_vbass_enh': 1,
        'mus_vbass_cls_en': 0,
        'mus_vbass_cls_cut': 50,
        'mus_vbass_cls_int': 12,
        'mus_3d_en': 0,
        'mus_3d_int': 30,
        'mus_3dplus_en': 0,
        'mus_3dplus_int': 30,
        'mus_stereo_en': 1,
        'mus_stereo_shp': 2,
        'mus_vcut_en': 0,
        'mus_vcut_val': 100,
        'mus_vrem_en': 0,
        'mus_vrem_lo': 200,
        'mus_vrem_hi': 15000,
        'mus_pitch_en': 0,
        'mus_pitch_key': 70,
        'mus_drc_en': 1,
        'mus_drc_xfreq': 300,
        'mus_drc_thr1': 0,
        'mus_drc_thr2': 0,
        'mus_drc_ratio1': 100,
        'mus_drc_ratio2': 100,
        'mus_drc_att1': 1,
        'mus_drc_rel': 1000,
        'mus_delay_en': 0,
        'mus_delay_val': 50,
        'mus_exciter_en': 1,
        'mus_exciter_cut': 3000,
        'mus_exciter_dry': 100,
        'mus_exciter_wet': 100,
        'mus_phase_en': 0,
        'mus_phase_diff': 0,
        'gain_mus': 4096,
        'gain_mic': 4096,
        'gain_mic_bypass': 4096,
        'gain_mic_echo': 3500,
        'gain_mic_rev': 3500,
        'gain_bt': 4096,
        'gain_usb': 4096,
        'gain_i2s': 4096,
        'gain_spdif': 4096,
    },
    'Deep Voice': {
        'mic_ns_en': 1,
        'mic_ns_thr': -4000,
        'mic_ns_ratio': 3,
        'mic_ns_attack': 2,
        'mic_ns_release': 100,
        'mic_howl_en': 1,
        'mic_howl_mode': 2,
        'mic_freq_en': 0,
        'mic_freq_delta': 0,
        'mic_silence_en': 1,
        'mic_silence_amp': 0,
        'mic_echo_en': 0,
        'mic_echo_cf': 8000,
        'mic_echo_att': 10000,
        'mic_echo_delay': 200,
        'mic_echo_max_delay': 350,
        'mic_echo_hq': 0,
        'mic_echo_dry': 100,
        'mic_echo_wet': 100,
        'mic_rev_en': 1,
        'mic_rev_dry': 100,
        'mic_rev_wet': 50,
        'mic_rev_width': 80,
        'mic_rev_room': 60,
        'mic_rev_damp': 30,
        'mic_plate_en': 0,
        'mic_plate_hcf': 8000,
        'mic_plate_mod': 1,
        'mic_plate_pre': 2000,
        'mic_plate_diff': 60,
        'mic_plate_decay': 50,
        'mic_plate_damp': 5000,
        'mic_plate_wet': 40,
        'mic_pitch_en': 1,
        'mic_pitch_key': 50,
        'mic_autotune_en': 0,
        'mic_autotune_key': 67,
        'mic_autotune_snap': 110,
        'mic_autotune_acc': 0,
        'mic_vch_en': 0,
        'mic_vch_pitch': 170,
        'mic_vch_formant': 130,
        'mic_drc_en': 0,
        'mic_drc_thr1': 0,
        'mic_drc_thr2': 0,
        'mic_drc_ratio1': 100,
        'mic_drc_ratio2': 100,
        'mic_drc_att': 1,
        'mic_drc_rel': 1000,
        'mus_ns_en': 1,
        'mus_ns_thr': -6000,
        'mus_ns_ratio': 2,
        'mus_ns_attack': 1,
        'mus_ns_release': 100,
        'mus_vbass_en': 1,
        'mus_vbass_cut': 90,
        'mus_vbass_int': 40,
        'mus_vbass_enh': 1,
        'mus_vbass_cls_en': 0,
        'mus_vbass_cls_cut': 50,
        'mus_vbass_cls_int': 12,
        'mus_3d_en': 0,
        'mus_3d_int': 40,
        'mus_3dplus_en': 1,
        'mus_3dplus_int': 60,
        'mus_stereo_en': 1,
        'mus_stereo_shp': 2,
        'mus_vcut_en': 0,
        'mus_vcut_val': 100,
        'mus_vrem_en': 0,
        'mus_vrem_lo': 200,
        'mus_vrem_hi': 15000,
        'mus_pitch_en': 0,
        'mus_pitch_key': 70,
        'mus_drc_en': 1,
        'mus_drc_xfreq': 300,
        'mus_drc_thr1': 0,
        'mus_drc_thr2': 0,
        'mus_drc_ratio1': 100,
        'mus_drc_ratio2': 100,
        'mus_drc_att1': 1,
        'mus_drc_rel': 1000,
        'mus_delay_en': 1,
        'mus_delay_val': 30,
        'mus_exciter_en': 0,
        'mus_exciter_cut': 1000,
        'mus_exciter_dry': 100,
        'mus_exciter_wet': 100,
        'mus_phase_en': 0,
        'mus_phase_diff': 0,
        'gain_mus': 4096,
        'gain_mic': 4096,
        'gain_mic_bypass': 3800,
        'gain_mic_echo': 3800,
        'gain_mic_rev': 4096,
        'gain_bt': 4096,
        'gain_usb': 4096,
        'gain_i2s': 4096,
        'gain_spdif': 4096,
    },
}



def _ensure_config_dir():
    os.makedirs(CONFIG_DIR, exist_ok=True)


def load_presets():
    _ensure_config_dir()
    presets = copy.deepcopy(DEFAULT_PRESETS)
    if os.path.isfile(PRESETS_PATH):
        try:
            with open(PRESETS_PATH, "r", encoding="utf-8") as f:
                presets.update(json.load(f))
        except Exception as e:
            print(f"[acpd] Błąd wczytywania presetów: {e}", file=sys.stderr)
    return presets


def save_presets(presets):
    _ensure_config_dir()
    with open(PRESETS_PATH, "w", encoding="utf-8") as f:
        json.dump(presets, f, indent=2, ensure_ascii=False)


def load_last_state():
    if os.path.isfile(STATE_PATH):
        try:
            with open(STATE_PATH, "r", encoding="utf-8") as f:
                st = json.load(f)
            merged = copy.deepcopy(DEFAULT_STATE)
            merged.update(st)
            return merged
        except Exception:
            pass
    return copy.deepcopy(DEFAULT_STATE)


def save_last_state(state):
    _ensure_config_dir()
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except Exception as e:
        print(f"[acpd] Błąd zapisu stanu: {e}", file=sys.stderr)


# ─────────────────────────────────────────────────────────────────────────
# AcpLink — 1:1 z acp_gui_qt2.py
# Trwałe połączenie USB, TYLKO iface 4 (HID/ACP). Audio iface 0–3 nietknięte.
# Bez set_configuration() — nie resetuje composite device.
# Connect = tylko open(); parametry lecą wyłącznie przy SetParam / LoadPreset
# (jak „Zastosuj” w Qt), NIE przy samym połączeniu.
# ─────────────────────────────────────────────────────────────────────────

class AcpLink:
    """
    Trwałe połączenie USB do BP1048B2 przez interface 4 (HID/ACP).
    Claim tylko iface 4 — audio (iface 0-3) zostaje nieruszone przez cały czas.
    Thread-safe dzięki locku.
    """

    def __init__(self):
        self._dev = None
        self._lock = threading.Lock()
        self._open = False

    def open(self) -> bool:
        if not _HAS_PYUSB:
            return False
        with self._lock:
            try:
                dev = _usb_core.find(idVendor=VID, idProduct=PID)
                if dev is None:
                    return False
                # Tylko iface 4 — audio iface 0-3 pozostają przy kernelu!
                try:
                    if dev.is_kernel_driver_active(4):
                        dev.detach_kernel_driver(4)
                except Exception:
                    pass
                _usb_util.claim_interface(dev, 4)
                self._dev = dev
                self._open = True
                return True
            except Exception as e:
                print(f"[AcpLink] open error: {e}", file=sys.stderr)
                return False

    def close(self):
        with self._lock:
            if self._dev:
                try:
                    _usb_util.release_interface(self._dev, 4)
                except Exception:
                    pass
                try:
                    self._dev.attach_kernel_driver(4)
                except Exception:
                    pass
                self._dev = None
            self._open = False

    def send(self, frame: bytes) -> str:
        """Wysyła pełną ramkę ACP. Nie otwiera/zamyka — używa trwałego połączenia."""
        with self._lock:
            if not self._dev:
                return "NOT_CONNECTED"
            try:
                pkt = bytes(frame[:64]).ljust(64, b"\x00")
                self._dev.ctrl_transfer(0x21, 0x09, 0x0200, 4, pkt)
                return "OK"
            except Exception as e:
                self._open = False
                return f"ERR: {e}"

    @property
    def is_open(self) -> bool:
        return self._open and self._dev is not None


def device_present() -> bool:
    if not _HAS_PYUSB:
        return False
    try:
        return _usb_core.find(idVendor=VID, idProduct=PID) is not None
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────
# D-Bus service
# ─────────────────────────────────────────────────────────────────────────

BUS_NAME = "org.mvsilicon.Acp"
OBJ_PATH = "/org/mvsilicon/Acp1"
IFACE = "org.mvsilicon.Acp1"

INTROSPECTION_XML = """
<node>
  <interface name="org.mvsilicon.Acp1">
    <method name="Connect">
      <arg type="b" direction="out" name="ok"/>
    </method>
    <method name="Disconnect"/>
    <method name="IsConnected">
      <arg type="b" direction="out" name="connected"/>
    </method>
    <method name="SetParam">
      <arg type="s" direction="in" name="key"/>
      <arg type="i" direction="in" name="value"/>
      <arg type="b" direction="out" name="ok"/>
    </method>
    <method name="GetState">
      <arg type="s" direction="out" name="json_state"/>
    </method>
    <method name="ListPresets">
      <arg type="as" direction="out" name="names"/>
    </method>
    <method name="LoadPreset">
      <arg type="s" direction="in" name="name"/>
      <arg type="b" direction="out" name="ok"/>
    </method>
    <method name="SaveFlash">
      <arg type="b" direction="out" name="ok"/>
    </method>
    <method name="RequestLock">
      <arg type="s" direction="in" name="owner"/>
      <arg type="b" direction="out" name="granted"/>
    </method>
    <method name="ReleaseLock">
      <arg type="s" direction="in" name="owner"/>
    </method>
    <method name="IsLocked">
      <arg type="b" direction="out" name="locked"/>
      <arg type="s" direction="out" name="owner"/>
    </method>
    <signal name="StateChanged">
      <arg type="s" name="json_state"/>
    </signal>
    <signal name="ConnectedChanged">
      <arg type="b" name="connected"/>
    </signal>
  </interface>
</node>
"""


class AcpDaemon:
    def __init__(self):
        self.link = AcpLink()
        self.state = load_last_state()
        self.presets = load_presets()
        self._lock_owner = None
        self._connection = None
        self._reg_id = None
        self._loop = GLib.MainLoop()
        self._poll_source = None

    # ── device / connect ──

    def do_connect(self) -> bool:
        if self._lock_owner:
            print(f"[acpd] Połączenie zablokowane przez '{self._lock_owner}', pomijam.", file=sys.stderr)
            return False
        if self.link.is_open:
            return True
        if not device_present():
            return False
        ok = self.link.open()
        if ok:
            # Jak ConnectWorker w acp_gui_qt2: tylko open iface 4, BEZ wgrywania parametrów.
            # Audio path zostaje przy stanie flash/firmware. Zmiany tylko SetParam/LoadPreset.
            print("[acpd] ✓ Trwałe połączenie iface 4 — audio bezpieczne (jak acp_gui_qt2)")
            if os.environ.get("ACPD_RESEND_ON_CONNECT", "").strip() in ("1", "true", "yes"):
                print("[acpd] ACPD_RESEND_ON_CONNECT=1 → wgrywam pełny stan (opcjonalne)")
                self._resend_full_state()
            self._emit_connected(True)
        return ok

    def do_disconnect(self):
        self.link.close()
        self._emit_connected(False)

    def is_connected(self) -> bool:
        return self.link.is_open

    # ── params ──

    def _send_module(self, mod_name, keys):
        if mod_name.startswith("__gain__"):
            gkey = mod_name[len("__gain__"):]
            mid, _label = GAIN_MODULES[gkey]
            val = self.state.get(gkey, 4096)
            params = u16([1, val, 0, 2])  # [enable, pregain, mute, channel] wg SDK
            frame = build_frame(mid, params)
        else:
            mid = (MIC_MODULES.get(mod_name) or MUS_MODULES.get(mod_name))[0]
            vals = [self.state.get(k, 0) for k in keys]
            frame = build_frame(mid, u16(vals))
        return self.link.send(frame)

    def _resend_full_state(self):
        """Wysyła stan FX (MIC+MUSIC). GAINy celowo pomijane — psuły ścieżkę audio."""
        ok_n = err_n = 0
        for mod_name, (_mid, keys) in {**MIC_MODULES, **MUS_MODULES}.items():
            try:
                resp = self._send_module(mod_name, keys)
                if resp == "OK":
                    ok_n += 1
                else:
                    err_n += 1
                    print(f"[acpd] preset/send {mod_name}: {resp}", file=sys.stderr)
            except Exception as e:
                err_n += 1
                print(f"[acpd] preset/send {mod_name} EXC: {e}", file=sys.stderr)
            time.sleep(0.012)
        # GAIN_MODULES — NIE wysyłamy (błędne zakresy / mute ścieżki)
        print(f"[acpd] resend FX: ok={ok_n} err={err_n} (gains skipped)", file=sys.stderr)

    def set_param(self, key: str, value: int) -> bool:
        if key not in KEY_TO_MODULE:
            print(f"[acpd] Nieznany klucz parametru: {key}", file=sys.stderr)
            return False
        self.state[key] = value
        save_last_state(self.state)
        mod_name = KEY_TO_MODULE[key]
        # Gainów nie wysyłamy do DSP (psują audio / złe zakresy)
        if mod_name.startswith("__gain__"):
            self._emit_state_changed()
            return True
        if not self.link.is_open:
            self._emit_state_changed()
            return True
        keys = (MIC_MODULES.get(mod_name) or MUS_MODULES.get(mod_name))[1]
        resp = self._send_module(mod_name, keys)
        self._emit_state_changed()
        return resp == "OK"

    def load_preset(self, name: str) -> bool:
        if name not in self.presets:
            print(f"[acpd] Brak presetu: {name!r} (znane: {list(self.presets)})", file=sys.stderr)
            return False
        # Aktualizuj stan lokalny od razu; USB w idle — żeby D-Bus nie dostał timeoutu
        self.state.update(self.presets[name])
        # nie trzymamy gainów w aktywnej ścieżce sterowania
        save_last_state(self.state)
        self._emit_state_changed()
        if self.link.is_open:
            def _do():
                print(f"[acpd] Wgrywam preset {name!r} (bez gainów)…")
                self._resend_full_state()
                self._emit_state_changed()
                return False  # one-shot idle
            GLib.idle_add(_do)
        return True

    def save_flash(self) -> bool:
        if not self.link.is_open:
            return False
        frame = build_frame(MODULE["SAVE_FLASH"], bytes([1]))
        return self.link.send(frame) == "OK"

    # ── locking (do arbitrażu z pełnym edytorem PyQt) ──

    def request_lock(self, owner: str) -> bool:
        if self._lock_owner and self._lock_owner != owner:
            return False
        self._lock_owner = owner
        self.link.close()
        self._emit_connected(False)
        print(f"[acpd] Lock USB przekazany do '{owner}' — daemon zwolnił urządzenie")
        return True

    def release_lock(self, owner: str):
        if self._lock_owner == owner:
            self._lock_owner = None
            print(f"[acpd] Lock zwolniony przez '{owner}', wracam do obsługi")
            GLib.idle_add(self.do_connect)

    # ── D-Bus plumbing ──

    def _emit_state_changed(self):
        if not self._connection:
            return
        self._connection.emit_signal(
            None, OBJ_PATH, IFACE, "StateChanged",
            GLib.Variant("(s)", (json.dumps(self.state),)),
        )

    def _emit_connected(self, connected: bool):
        if not self._connection:
            return
        self._connection.emit_signal(
            None, OBJ_PATH, IFACE, "ConnectedChanged",
            GLib.Variant("(b)", (connected,)),
        )

    def handle_method_call(self, connection, sender, object_path, interface_name,
                            method_name, parameters, invocation):
        try:
            args = parameters.unpack()
            if method_name == "Connect":
                ok = self.do_connect()
                invocation.return_value(GLib.Variant("(b)", (ok,)))
            elif method_name == "Disconnect":
                self.do_disconnect()
                invocation.return_value(None)
            elif method_name == "IsConnected":
                invocation.return_value(GLib.Variant("(b)", (self.is_connected(),)))
            elif method_name == "SetParam":
                key, value = args
                ok = self.set_param(key, int(value))
                invocation.return_value(GLib.Variant("(b)", (ok,)))
            elif method_name == "GetState":
                invocation.return_value(GLib.Variant("(s)", (json.dumps(self.state),)))
            elif method_name == "ListPresets":
                invocation.return_value(GLib.Variant("(as)", (list(self.presets.keys()),)))
            elif method_name == "LoadPreset":
                (name,) = args
                ok = self.load_preset(name)
                invocation.return_value(GLib.Variant("(b)", (ok,)))
            elif method_name == "SaveFlash":
                ok = self.save_flash()
                invocation.return_value(GLib.Variant("(b)", (ok,)))
            elif method_name == "RequestLock":
                (owner,) = args
                granted = self.request_lock(owner)
                invocation.return_value(GLib.Variant("(b)", (granted,)))
            elif method_name == "ReleaseLock":
                (owner,) = args
                self.release_lock(owner)
                invocation.return_value(None)
            elif method_name == "IsLocked":
                invocation.return_value(GLib.Variant(
                    "(bs)", (bool(self._lock_owner), self._lock_owner or "")))
            else:
                invocation.return_error_literal(
                    Gio.dbus_error_quark(), Gio.DBusError.UNKNOWN_METHOD,
                    f"Unknown method {method_name}")
        except Exception as e:
            print(f"[acpd] Błąd obsługi {method_name}: {e}", file=sys.stderr)
            invocation.return_error_literal(
                Gio.dbus_error_quark(), Gio.DBusError.FAILED, str(e))

    def on_bus_acquired(self, connection, name):
        self._connection = connection
        node_info = Gio.DBusNodeInfo.new_for_xml(INTROSPECTION_XML)
        self._reg_id = connection.register_object(
            OBJ_PATH, node_info.interfaces[0], self.handle_method_call, None, None)
        print(f"[acpd] D-Bus: zarejestrowano {IFACE} na {OBJ_PATH}")
        # Poll obecności urządzenia co 3s — auto (re)connect po podłączeniu USB
        self._poll_source = GLib.timeout_add_seconds(3, self._poll_device)
        GLib.idle_add(self.do_connect)

    def on_name_lost(self, connection, name):
        print(f"[acpd] Nie udało się przejąć nazwy {name} na sesyjnej magistrali "
              f"(inny acpd już działa?)", file=sys.stderr)

    def _poll_device(self):
        if not self.link.is_open and not self._lock_owner:
            self.do_connect()
        elif self.link.is_open and not device_present():
            print("[acpd] Urządzenie zniknęło", file=sys.stderr)
            self.do_disconnect()
        return GLib.SOURCE_CONTINUE

    def run(self):
        owner_id = Gio.bus_own_name(
            Gio.BusType.SESSION, BUS_NAME, Gio.BusNameOwnerFlags.NONE,
            self.on_bus_acquired, None, self.on_name_lost)

        def _sigterm(*_a):
            print("[acpd] Zamykanie…")
            self.link.close()
            self._loop.quit()

        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, _sigterm)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGINT, _sigterm)

        try:
            self._loop.run()
        finally:
            Gio.bus_unown_name(owner_id)


def main():
    if not _HAS_PYUSB:
        print("[acpd] UWAGA: brak pyusb — daemon wystartuje, ale nie połączy się "
              "z urządzeniem. `pip install pyusb --break-system-packages`", file=sys.stderr)
    daemon = AcpDaemon()
    daemon.run()


if __name__ == "__main__":
    main()
