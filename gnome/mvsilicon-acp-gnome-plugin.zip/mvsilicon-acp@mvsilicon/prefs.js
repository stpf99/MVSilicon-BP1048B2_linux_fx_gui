import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gio from 'gi://Gio';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class MvsiliconAcpPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        let page = new Adw.PreferencesPage({
            title: 'MVSilicon ACP',
            icon_name: 'audio-headphones-symbolic',
        });
        window.add(page);

        let group = new Adw.PreferencesGroup({ title: 'Ogólne' });
        page.add(group);

        let notifyRow = new Adw.SwitchRow({ title: 'Powiadomienia systemowe' });
        group.add(notifyRow);
        settings.bind('show-notifications', notifyRow, 'active', Gio.SettingsBindFlags.DEFAULT);

        let iconRow = new Adw.EntryRow({ title: 'Ikona panelu (symbolic)' });
        group.add(iconRow);
        settings.bind('panel-icon', iconRow, 'text', Gio.SettingsBindFlags.DEFAULT);

        let editorGroup = new Adw.PreferencesGroup({
            title: 'Pełny edytor (undock)',
            description: 'Ścieżka do acp_gui_gtk.py lub innej aplikacji GTK/Qt komunikującej się z acpd.',
        });
        page.add(editorGroup);

        let pathRow = new Adw.EntryRow({ title: 'Ścieżka edytora' });
        editorGroup.add(pathRow);
        settings.bind('full-editor-path', pathRow, 'text', Gio.SettingsBindFlags.DEFAULT);

        let help = new Adw.ActionRow({
            title: 'Wymagany daemon',
            subtitle: 'acpd.py musi działać na session bus (org.mvsilicon.Acp).\nUruchom: systemctl --user enable --now mvsilicon-acpd.service',
        });
        editorGroup.add(help);
    }
}
