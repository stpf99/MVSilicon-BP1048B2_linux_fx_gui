#!/usr/bin/env python3
"""ACP DSP Workbench GTK4 — no gains, presets, curves."""
from __future__ import annotations
import json, math, sys, gi
gi.require_version("Gtk","4.0"); gi.require_version("Adw","1")
gi.require_version("Gio","2.0"); gi.require_version("GLib","2.0")
from gi.repository import Gtk, Adw, Gio, GLib, Gdk
BUS,OBJ,IF="org.mvsilicon.Acp","/org/mvsilicon/Acp1","org.mvsilicon.Acp1"
CSS=b"window{background:#0d1117}.acp-title{font-weight:800;font-size:15pt}.acp-status-ok{color:#3fb950;font-weight:700}.acp-status-off{color:#f85149;font-weight:700}.acp-card{background:#161b22;border-radius:12px;border:1px solid #30363d;padding:10px;margin:4px}.acp-card-title{color:#58a6ff;font-weight:700;font-size:11pt}.acp-preset-btn{border-radius:20px;padding:4px 14px;font-weight:600}.acp-meter-frame{background:#010409;border-radius:8px;border:1px solid #21262d}"
MIC=[("Noise",[("mic_ns_en","NS",None,None),("mic_ns_thr","Thr",-9999,0),("mic_ns_ratio","Ratio",1,10),("mic_howl_en","Howl",None,None),("mic_howl_mode","Mode",1,3),("mic_freq_en","FShift",None,None),("mic_freq_delta","dF",-100,100),("mic_silence_en","Silence",None,None)]),
("Echo",[("mic_echo_en","On",None,None),("mic_echo_delay","Delay",10,500),("mic_echo_att","Att",0,65535),("mic_echo_wet","Wet",0,100),("mic_echo_dry","Dry",0,100),("mic_echo_cf","Cut",100,16000)]),
("Reverb",[("mic_rev_en","Room",None,None),("mic_rev_wet","Wet",0,100),("mic_rev_room","Size",0,100),("mic_rev_damp","Damp",0,100),("mic_plate_en","Plate",None,None),("mic_plate_decay","Decay",0,100),("mic_plate_wet","Wet",0,100),("mic_plate_pre","Pre",0,5000)]),
("Pitch/AT",[("mic_pitch_en","Pitch",None,None),("mic_pitch_key","Key",30,90),("mic_autotune_en","AT",None,None),("mic_autotune_key","Key",30,110),("mic_autotune_snap","Snap",0,200),("mic_vch_en","VCh",None,None),("mic_vch_pitch","P",50,400),("mic_vch_formant","F",50,200)]),
("DRC",[("mic_drc_en","On",None,None),("mic_drc_thr1","Thr1",-9999,0),("mic_drc_ratio1","R1",1,200),("mic_drc_att","Att",1,100),("mic_drc_rel","Rel",10,5000)])]
MUS=[("Bass",[("mus_ns_en","NS",None,None),("mus_ns_thr","Thr",-9999,0),("mus_vbass_en","VBass",None,None),("mus_vbass_cut","Cut",20,300),("mus_vbass_int","Int",0,100),("mus_vbass_enh","Enh",None,None),("mus_vbass_cls_en","Classic",None,None)]),
("3D/Stereo",[("mus_3d_en","3D",None,None),("mus_3d_int","Int",0,100),("mus_3dplus_en","3D+",None,None),("mus_3dplus_int","Int",0,100),("mus_stereo_en","Stereo",None,None),("mus_stereo_shp","Shp",1,3),("mus_phase_en","Phase",None,None)]),
("Voice",[("mus_vcut_en","VCut",None,None),("mus_vcut_val","Mix",0,100),("mus_vrem_en","VRem",None,None),("mus_vrem_lo","Lo",20,2000),("mus_vrem_hi","Hi",5000,20000),("mus_pitch_en","Pitch",None,None),("mus_pitch_key","Key",30,110)]),
("DRC/FX",[("mus_drc_en","DRC",None,None),("mus_drc_xfreq","Xover",20,2000),("mus_delay_en","Delay",None,None),("mus_delay_val","ms",0,500),("mus_exciter_en","Exc",None,None),("mus_exciter_cut","Cut",200,16000)])]
class C:
 def __init__(s):
  s.p=None;s.st={};s.ok=False;s.os=None;s.oc=None
 def connect(s):
  try:
   s.p=Gio.DBusProxy.new_for_bus_sync(Gio.BusType.SESSION,Gio.DBusProxyFlags.NONE,None,BUS,OBJ,IF,None)
   s.p.connect("g-signal",s._sig);s.refresh()
   try:
    s.p.call_sync("Connect",None,Gio.DBusCallFlags.NONE,3000,None)
   except Exception:
    pass
   return True
  except Exception as e:
   print(e,file=sys.stderr);return False
 def _sig(s,p,snd,sig,par):
  if sig=="StateChanged":
   (j,)=par.unpack()
   try: s.st=json.loads(j)
   except Exception: return
   if s.os: GLib.idle_add(s.os,s.st)
  elif sig=="ConnectedChanged":
   (c,)=par.unpack();s.ok=bool(c)
   if s.oc: GLib.idle_add(s.oc,s.ok)
 def refresh(s):
  if not s.p: return
  try:
   r=s.p.call_sync("GetState",None,Gio.DBusCallFlags.NONE,2000,None);(j,)=r.unpack();s.st=json.loads(j)
  except Exception: pass
  try:
   r=s.p.call_sync("IsConnected",None,Gio.DBusCallFlags.NONE,1000,None);(c,)=r.unpack();s.ok=bool(c)
  except Exception: s.ok=False
 def set(s,k,v):
  if not s.p: return False
  try:
   r=s.p.call_sync("SetParam",GLib.Variant("(si)",(k,int(v))),Gio.DBusCallFlags.NONE,2000,None);(o,)=r.unpack();s.st[k]=int(v);return bool(o)
  except Exception: return False
 def presets(s):
  if not s.p: return []
  try:
   r=s.p.call_sync("ListPresets",None,Gio.DBusCallFlags.NONE,2000,None);(n,)=r.unpack();return list(n)
  except Exception: return []
 def load(s,n):
  if not s.p: return False
  try:
   r=s.p.call_sync("LoadPreset",GLib.Variant("(s)",(n,)),Gio.DBusCallFlags.NONE,3000,None);(o,)=r.unpack()
   if o: s.refresh()
   return bool(o)
  except Exception: return False
 def flash(s):
  if not s.p: return False
  try:
   r=s.p.call_sync("SaveFlash",None,Gio.DBusCallFlags.NONE,3000,None);(o,)=r.unpack();return bool(o)
  except Exception: return False
class CV(Gtk.DrawingArea):
 def __init__(s,mode="drc",h=100):
  super().__init__();s.mode=mode;s.pr={};s.set_content_height(h);s.set_hexpand(True);s.set_draw_func(s.d);s.add_css_class("acp-meter-frame")
 def up(s,st): s.pr=st or {};s.queue_draw()
 def d(s,a,cr,w,h):
  cr.set_source_rgb(.02,.04,.07);cr.rectangle(0,0,w,h);cr.fill()
  cr.set_source_rgba(.2,.25,.35,.5);cr.set_line_width(1)
  for i in range(1,4):
   y=h*i/4;cr.move_to(0,y);cr.line_to(w,y);cr.stroke();x=w*i/4;cr.move_to(x,0);cr.line_to(x,h);cr.stroke()
  en=s.pr
  if s.mode=="bass":
   cut=float(en.get("mus_vbass_cut",80));it=float(en.get("mus_vbass_int",7));on=en.get("mus_vbass_en",0)
   (cr.set_source_rgb(.35,.65,1) if on else cr.set_source_rgba(.4,.45,.5,.7));cr.set_line_width(2.5);pk=it/100
   for i in range(max(1,w)):
    x=i/max(1,w-1);b=pk*math.exp(-((x*300-cut)/max(20,cut*.5))**2);y=h*(.7-b*.55)
    (cr.move_to if i==0 else cr.line_to)(i,y)
   cr.stroke()
  elif s.mode=="drc":
   thr=float(en.get("mus_drc_thr1",en.get("mic_drc_thr1",-2000)));ra=float(en.get("mus_drc_ratio1",en.get("mic_drc_ratio1",100)));on=en.get("mus_drc_en",en.get("mic_drc_en",0))
   t=max(.05,min(.95,1+thr/10000));r=max(1.,min(20.,ra/10))
   (cr.set_source_rgb(0,.83,.67) if on else cr.set_source_rgba(.4,.45,.5,.7));cr.set_line_width(2.5)
   cr.move_to(0,h*.85);kx,ky=w*t,h*(.85-t*.5);cr.line_to(kx,ky);cr.line_to(w,max(8,ky-(h*.35)/r));cr.stroke()
  elif s.mode=="reverb":
   wet=float(en.get("mic_plate_wet",en.get("mic_rev_wet",50)))/100;dec=float(en.get("mic_plate_decay",en.get("mic_rev_room",50)))/100;on=en.get("mic_plate_en",en.get("mic_rev_en",0))
   (cr.set_source_rgb(.7,.45,1) if on else cr.set_source_rgba(.4,.45,.5,.7));cr.set_line_width(2)
   for i in range(max(1,w)):
    x=i/max(1,w-1);e=wet*math.exp(-x*(1.5+(1-dec)*4));y=h*(.9-e*.75)
    (cr.move_to if i==0 else cr.line_to)(i,y)
   cr.stroke()
  else:
   ks=["mus_vbass_en","mus_3d_en","mus_stereo_en","mic_echo_en","mic_plate_en","mic_autotune_en"];bw=w/(len(ks)*1.6)
   for i,k in enumerate(ks):
    on=bool(en.get(k,0));x=12+i*(bw*1.6);bh=h*(.55 if on else .18)
    (cr.set_source_rgb(0,.83,.67) if on else cr.set_source_rgba(.3,.35,.4,.8))
    cr.rectangle(x,h-bh-8,bw,bh);cr.fill()
class Row(Gtk.Box):
 def __init__(s,key,lab,vmin,vmax,cli,cb=None):
  super().__init__(orientation=Gtk.Orientation.HORIZONTAL,spacing=8)
  s.key=key;s.cli=cli;s.cb=cb;s.sup=False
  s.set_margin_start(4);s.set_margin_end(4);s.set_margin_top(2);s.set_margin_bottom(2)
  s.append(Gtk.Label(label=lab,xalign=0,hexpand=True))
  if vmin is None:
   s.w=Gtk.Switch();s.w.set_valign(Gtk.Align.CENTER);s.w.connect("notify::active",s._sw)
  else:
   s.w=Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,vmin,vmax,1);s.w.set_hexpand(True);s.w.set_draw_value(True);s.w.set_value_pos(Gtk.PositionType.RIGHT);s.w.set_size_request(180,-1);s.w.connect("value-changed",s._sc)
  s.append(s.w)
 def _sw(s,*a):
  if s.sup: return
  s.cli.set(s.key,1 if s.w.get_active() else 0)
  if s.cb: s.cb()
 def _sc(s,*a):
  if s.sup: return
  s.cli.set(s.key,int(s.w.get_value()))
  if s.cb: s.cb()
 def apply(s,v):
  s.sup=True
  if isinstance(s.w,Gtk.Switch): s.w.set_active(bool(v))
  else: s.w.set_value(float(v))
  s.sup=False
def card(title,ch):
 b=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4);b.add_css_class("acp-card")
 t=Gtk.Label(label=title,xalign=0);t.add_css_class("acp-card-title");b.append(t);b.append(ch);return b
class W(Adw.ApplicationWindow):
 def __init__(s,app,cli):
  super().__init__(application=app,title="ACP Workbench");s.cli=cli;s.rows={};s.cvs=[];s.set_default_size(960,700)
  pr=Gtk.CssProvider();pr.load_from_data(CSS)
  Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(),pr,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
  tv=Adw.ToolbarView();hb=Adw.HeaderBar();tl=Gtk.Label(label="ACP Workbench");tl.add_css_class("acp-title");hb.set_title_widget(tl)
  s.st=Gtk.Label(label="...");s.st.add_css_class("acp-status-off");hb.pack_start(s.st)
  bf=Gtk.Button(label="Flash");bf.add_css_class("suggested-action");bf.connect("clicked",lambda *_: s.st.set_text("Flash OK" if s.cli.flash() else "ERR"));hb.pack_end(bf)
  br=Gtk.Button(icon_name="view-refresh-symbolic");br.connect("clicked",lambda *_: s.full());hb.pack_end(br);tv.add_top_bar(hb)
  pb=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8);pb.set_margin_start(12);pb.set_margin_end(12);pb.set_margin_top(8);pb.set_margin_bottom(4)
  pb.append(Gtk.Label(label="Presety:"));s.pf=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=6);s.pf.set_hexpand(True);pb.append(s.pf)
  cr=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=6);cr.set_margin_start(8);cr.set_margin_end(8);cr.set_margin_bottom(4)
  for t,m in (("Bass","bass"),("DRC","drc"),("Reverb","reverb"),("FX","levels")):
   c=CV(m,100);s.cvs.append(c);cr.append(card(t,c))
  nb=Gtk.Notebook();nb.set_vexpand(True)
  nb.append_page(s.page(MIC),Gtk.Label(label="Mikrofon"));nb.append_page(s.page(MUS),Gtk.Label(label="Muzyka"))
  out=Gtk.Box(orientation=Gtk.Orientation.VERTICAL);out.append(pb);out.append(cr);out.append(nb);tv.set_content(out);s.set_content(tv)
  cli.os=s.on_st;cli.oc=s.on_c;s.full()
 def page(s,groups):
  sc=Gtk.ScrolledWindow();sc.set_vexpand(True);sc.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
  g=Gtk.FlowBox();g.set_valign(Gtk.Align.START);g.set_max_children_per_line(2);g.set_min_children_per_line(1)
  g.set_selection_mode(Gtk.SelectionMode.NONE);g.set_homogeneous(False);g.set_column_spacing(6);g.set_row_spacing(6)
  g.set_margin_start(6);g.set_margin_end(6);g.set_margin_top(6);g.set_margin_bottom(10)
  for gt,cs in groups:
   inn=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=2)
   for k,l,a,b in cs:
    r=Row(k,l,a,b,s.cli,s.upd);s.rows[k]=r;inn.append(r)
   g.append(card(gt,inn))
  sc.set_child(g);return sc
 def upd(s):
  for c in s.cvs: c.up(s.cli.st)
 def full(s):
  s.cli.refresh();s.on_c(s.cli.ok);s.on_st(s.cli.st)
  while True:
   ch=s.pf.get_first_child()
   if not ch: break
   s.pf.remove(ch)
  for n in s.cli.presets():
   b=Gtk.Button(label=n);b.add_css_class("acp-preset-btn");b.add_css_class("flat")
   b.connect("clicked",lambda _b,n=n: s.ld(n));s.pf.append(b)
 def ld(s,n):
  o=s.cli.load(n);s.on_st(s.cli.st);s.st.set_text(("Preset: "+n) if o else "ERR")
 def on_st(s,st):
  for k,r in s.rows.items():
   if k in st: r.apply(st[k])
  s.upd();return False
 def on_c(s,c):
  if c:
   s.st.set_text("BP1048B2");s.st.remove_css_class("acp-status-off");s.st.add_css_class("acp-status-ok")
  else:
   s.st.set_text("offline");s.st.remove_css_class("acp-status-ok");s.st.add_css_class("acp-status-off")
  return False
class App(Adw.Application):
 def __init__(s):
  super().__init__(application_id="org.mvsilicon.AcpGui");s.cli=C()
 def do_activate(s):
  o=s.cli.connect();w=W(s,s.cli);w.present()
  if not o:
   d=Adw.MessageDialog(heading="acpd offline",body="systemctl --user start mvsilicon-acpd",transient_for=w);d.add_response("ok","OK");d.present()
def main():
 return App().run(sys.argv)
if __name__=="__main__":
 sys.exit(main() or 0)
