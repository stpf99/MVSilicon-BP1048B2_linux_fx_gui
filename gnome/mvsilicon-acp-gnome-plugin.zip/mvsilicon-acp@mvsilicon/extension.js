import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Clutter from 'gi://Clutter';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as Slider from 'resource:///org/gnome/shell/ui/slider.js';

import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const BUS_NAME = 'org.mvsilicon.Acp';
const OBJ_PATH = '/org/mvsilicon/Acp1';
const IFACE = 'org.mvsilicon.Acp1';

const IFACE_XML = `
<node>
  <interface name="org.mvsilicon.Acp1">
    <method name="Connect"><arg type="b" direction="out" name="ok"/></method>
    <method name="Disconnect"/>
    <method name="IsConnected"><arg type="b" direction="out" name="connected"/></method>
    <method name="SetParam">
      <arg type="s" direction="in" name="key"/>
      <arg type="i" direction="in" name="value"/>
      <arg type="b" direction="out" name="ok"/>
    </method>
    <method name="GetState"><arg type="s" direction="out" name="json_state"/></method>
    <method name="ListPresets"><arg type="as" direction="out" name="names"/></method>
    <method name="LoadPreset">
      <arg type="s" direction="in" name="name"/>
      <arg type="b" direction="out" name="ok"/>
    </method>
    <method name="SaveFlash"><arg type="b" direction="out" name="ok"/></method>
    <signal name="StateChanged"><arg type="s" name="json_state"/></signal>
    <signal name="ConnectedChanged"><arg type="b" name="connected"/></signal>
  </interface>
</node>`;

const SliderRow = GObject.registerClass(
class SliderRow extends PopupMenu.PopupBaseMenuItem {
    _init(label, min, max, initial, onChange) {
        super._init({ reactive: false, can_focus: false });
        this._min = min;
        this._max = max;
        this._onChange = onChange;
        this._suppress = false;

        let box = new St.BoxLayout({ vertical: true, x_expand: true });
        let top = new St.BoxLayout({ x_expand: true });
        this._label = new St.Label({
            text: label,
            y_align: Clutter.ActorAlign.CENTER,
            x_expand: true,
        });
        this._valueLabel = new St.Label({
            text: String(initial),
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'popup-inactive-menu-item',
        });
        top.add_child(this._label);
        top.add_child(this._valueLabel);
        box.add_child(top);

        let norm = (initial - min) / Math.max(1, max - min);
        this._slider = new Slider.Slider(Math.max(0, Math.min(1, norm)));
        this._slider.connect('notify::value', () => {
            if (this._suppress) return;
            let v = Math.round(this._min + this._slider.value * (this._max - this._min));
            this._valueLabel.text = String(v);
            if (this._onChange) this._onChange(v);
        });
        box.add_child(this._slider);
        this.add_child(box);
    }

    setValue(v) {
        this._suppress = true;
        let norm = (v - this._min) / Math.max(1, this._max - this._min);
        this._slider.value = Math.max(0, Math.min(1, norm));
        this._valueLabel.text = String(v);
        this._suppress = false;
    }
});

const AcpIndicator = GObject.registerClass(
class AcpIndicator extends PanelMenu.Button {
    _init(settings, extension) {
        super._init(0.0, _('MVSilicon ACP'), false);
        this._settings = settings;
        this._ext = extension;
        this._proxy = null;
        this._state = {};
        this._connected = false;
        this._sliders = {};
        this._switches = {};
        this._presetsSection = null;
        this._statusLabel = null;
        this._debounceTimers = {};
        this._applyingState = false;

        let iconName = settings.get_string('panel-icon') || 'audio-headphones-symbolic';
        this._icon = new St.Icon({
            icon_name: iconName,
            style_class: 'system-status-icon',
        });
        this.add_child(this._icon);
        this._buildMenu();
        this._connectProxy();
    }

    _buildMenu() {
        this._statusLabel = new St.Label({ text: _('Szukam acpd…') });
        let statusItem = new PopupMenu.PopupBaseMenuItem({ reactive: false });
        statusItem.add_child(this._statusLabel);
        this.menu.addMenuItem(statusItem);

        let connItem = new PopupMenu.PopupMenuItem(_('🔌 Połącz z DSP'));
        connItem.connect('activate', () => this._call('Connect'));
        this.menu.addMenuItem(connItem);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        let presetsHeader = new PopupMenu.PopupMenuItem(_('📋  Presety'), { reactive: false });
        presetsHeader.setSensitive(false);
        this.menu.addMenuItem(presetsHeader);
        this._presetsSection = new PopupMenu.PopupMenuSection();
        this.menu.addMenuItem(this._presetsSection);
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._musicSub = new PopupMenu.PopupSubMenuMenuItem(_('🎵  Muzyka'));
        this.menu.addMenuItem(this._musicSub);
        this._fillMusic(this._musicSub.menu);

        this._micSub = new PopupMenu.PopupSubMenuMenuItem(_('🎤  Mikrofon'));
        this.menu.addMenuItem(this._micSub);
        this._fillMic(this._micSub.menu);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        let saveItem = new PopupMenu.PopupMenuItem(_('💾 Zapisz do flash DSP'));
        saveItem.connect('activate', () => {
            this._call('SaveFlash').then(ok => {
                if (this._settings.get_boolean('show-notifications'))
                    Main.notify('MVSilicon ACP', ok ? _('Zapisano do flash') : _('Błąd zapisu'));
            });
        });
        this.menu.addMenuItem(saveItem);

        let openItem = new PopupMenu.PopupMenuItem(_('🗔 Otwórz pełny edytor'));
        openItem.connect('activate', () => this._openFullEditor());
        this.menu.addMenuItem(openItem);

        let refreshItem = new PopupMenu.PopupMenuItem(_('🔄 Odśwież stan'));
        refreshItem.connect('activate', () => this._refreshState());
        this.menu.addMenuItem(refreshItem);
    }

    _fillMusic(menu) {
        this._addSwitchTo(menu, 'mus_vbass_en', _('Virtual Bass'));
        this._addSliderTo(menu, 'mus_vbass_cut', _('Bass cutoff Hz'), 20, 300);
        this._addSliderTo(menu, 'mus_vbass_int', _('Bass intensity'), 0, 100);
        this._addSwitchTo(menu, 'mus_vbass_enh', _('Bass enhanced'));
        this._addSwitchTo(menu, 'mus_vbass_cls_en', _('Bass classic'));
        this._addSliderTo(menu, 'mus_vbass_cls_int', _('Classic intensity'), 0, 50);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._addSwitchTo(menu, 'mus_3d_en', _('3D Surround'));
        this._addSliderTo(menu, 'mus_3d_int', _('3D intensity'), 0, 100);
        this._addSwitchTo(menu, 'mus_3dplus_en', _('3D Plus'));
        this._addSliderTo(menu, 'mus_3dplus_int', _('3D+ intensity'), 0, 100);
        this._addSwitchTo(menu, 'mus_stereo_en', _('Stereo Widener'));
        this._addSliderTo(menu, 'mus_stereo_shp', _('Stereo shape 1–3'), 1, 3);
        this._addSwitchTo(menu, 'mus_phase_en', _('Phase shift'));
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._addSwitchTo(menu, 'mus_vcut_en', _('Voice Cut'));
        this._addSliderTo(menu, 'mus_vcut_val', _('VCut mix %'), 0, 100);
        this._addSwitchTo(menu, 'mus_vrem_en', _('Voice Remove'));
        this._addSliderTo(menu, 'mus_vrem_lo', _('VR low Hz'), 20, 2000);
        this._addSliderTo(menu, 'mus_vrem_hi', _('VR high Hz'), 5000, 20000);
        this._addSwitchTo(menu, 'mus_pitch_en', _('Pitch'));
        this._addSliderTo(menu, 'mus_pitch_key', _('Pitch key'), 30, 110);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._addSwitchTo(menu, 'mus_ns_en', _('Noise suppress'));
        this._addSliderTo(menu, 'mus_ns_thr', _('NS threshold'), -9999, 0);
        this._addSwitchTo(menu, 'mus_drc_en', _('Music DRC'));
        this._addSliderTo(menu, 'mus_drc_xfreq', _('DRC xover Hz'), 20, 2000);
        this._addSwitchTo(menu, 'mus_delay_en', _('PCM Delay'));
        this._addSliderTo(menu, 'mus_delay_val', _('Delay ms'), 0, 500);
        this._addSwitchTo(menu, 'mus_exciter_en', _('Exciter'));
        this._addSliderTo(menu, 'mus_exciter_cut', _('Exciter cut Hz'), 200, 16000);
    }

    _fillMic(menu) {
        this._addSwitchTo(menu, 'mic_ns_en', _('Noise suppress'));
        this._addSliderTo(menu, 'mic_ns_thr', _('NS threshold'), -9999, 0);
        this._addSliderTo(menu, 'mic_ns_ratio', _('NS ratio'), 1, 10);
        this._addSwitchTo(menu, 'mic_howl_en', _('Howling suppress'));
        this._addSliderTo(menu, 'mic_howl_mode', _('Howl mode 1–3'), 1, 3);
        this._addSwitchTo(menu, 'mic_freq_en', _('Freq shifter'));
        this._addSliderTo(menu, 'mic_freq_delta', _('Delta-F'), -100, 100);
        this._addSwitchTo(menu, 'mic_silence_en', _('Silence detector'));
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._addSwitchTo(menu, 'mic_echo_en', _('Echo'));
        this._addSliderTo(menu, 'mic_echo_delay', _('Echo delay ms'), 10, 500);
        this._addSliderTo(menu, 'mic_echo_att', _('Echo atten'), 0, 65535);
        this._addSliderTo(menu, 'mic_echo_wet', _('Echo wet'), 0, 100);
        this._addSliderTo(menu, 'mic_echo_dry', _('Echo dry'), 0, 100);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._addSwitchTo(menu, 'mic_rev_en', _('Reverb room'));
        this._addSliderTo(menu, 'mic_rev_wet', _('Rev wet'), 0, 100);
        this._addSliderTo(menu, 'mic_rev_room', _('Room size'), 0, 100);
        this._addSliderTo(menu, 'mic_rev_damp', _('Damping'), 0, 100);
        this._addSwitchTo(menu, 'mic_plate_en', _('Plate reverb'));
        this._addSliderTo(menu, 'mic_plate_decay', _('Plate decay'), 0, 100);
        this._addSliderTo(menu, 'mic_plate_wet', _('Plate wet'), 0, 100);
        this._addSliderTo(menu, 'mic_plate_pre', _('Pre-delay'), 0, 5000);
        menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._addSwitchTo(menu, 'mic_pitch_en', _('Pitch'));
        this._addSliderTo(menu, 'mic_pitch_key', _('Pitch key'), 30, 90);
        this._addSwitchTo(menu, 'mic_autotune_en', _('Auto Tune'));
        this._addSliderTo(menu, 'mic_autotune_key', _('AT key'), 30, 110);
        this._addSliderTo(menu, 'mic_autotune_snap', _('AT snap'), 0, 200);
        this._addSwitchTo(menu, 'mic_vch_en', _('Voice changer'));
        this._addSliderTo(menu, 'mic_vch_pitch', _('VC pitch'), 50, 400);
        this._addSliderTo(menu, 'mic_vch_formant', _('VC formant'), 50, 200);
        this._addSwitchTo(menu, 'mic_drc_en', _('Mic DRC'));
        this._addSliderTo(menu, 'mic_drc_thr1', _('DRC thr1'), -9999, 0);
        this._addSliderTo(menu, 'mic_drc_ratio1', _('DRC ratio1'), 1, 200);
    }

    _addSwitchTo(menu, key, label) {
        let item = new PopupMenu.PopupSwitchMenuItem(label, false);
        item.connect('toggled', (sw) => this._setParam(key, sw.state ? 1 : 0));
        menu.addMenuItem(item);
        this._switches[key] = item;
    }

    _addSliderTo(menu, key, label, min, max) {
        let row = new SliderRow(label, min, max, min, (v) => this._setParamDebounced(key, v));
        menu.addMenuItem(row);
        this._sliders[key] = row;
    }

    _setParamDebounced(key, value) {
        if (this._debounceTimers[key])
            GLib.source_remove(this._debounceTimers[key]);
        this._debounceTimers[key] = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 80, () => {
            this._debounceTimers[key] = 0;
            this._setParam(key, value);
            return GLib.SOURCE_REMOVE;
        });
    }

    _setParam(key, value) {
        if (!this._proxy) return;
        // Nie wysyłaj do DSP gdy tylko synchronizujemy UI ze stanem (po connect/GetState)
        if (this._applyingState) {
            this._state[key] = value;
            return;
        }
        this._state[key] = value;
        this._proxy.call(
            'SetParam', new GLib.Variant('(si)', [key, value]),
            Gio.DBusCallFlags.NONE, -1, null,
            (proxy, res) => { try { proxy.call_finish(res); } catch (e) {} }
        );
    }

    _call(method, params = null) {
        return new Promise((resolve, reject) => {
            if (!this._proxy) { reject(new Error('no proxy')); return; }
            this._proxy.call(method, params, Gio.DBusCallFlags.NONE, -1, null, (proxy, res) => {
                try {
                    let result = proxy.call_finish(res);
                    resolve(result ? result.deep_unpack()[0] : null);
                } catch (e) { reject(e); }
            });
        });
    }

    _connectProxy() {
        let ifaceInfo = null;
        try { ifaceInfo = Gio.DBusNodeInfo.new_for_xml(IFACE_XML).interfaces[0]; } catch (e) {}
        Gio.DBusProxy.new_for_bus(
            Gio.BusType.SESSION, Gio.DBusProxyFlags.NONE, ifaceInfo,
            BUS_NAME, OBJ_PATH, IFACE, null,
            (src, res) => {
                try {
                    this._proxy = Gio.DBusProxy.new_for_bus_finish(res);
                    this._proxy.connect('g-signal', (_p, _s, signal, params) => {
                        if (signal === 'StateChanged') {
                            let [json] = params.deep_unpack();
                            this._applyState(json);
                        } else if (signal === 'ConnectedChanged') {
                            let [c] = params.deep_unpack();
                            this._setConnected(c);
                        }
                    });
                    this._proxy.connect('notify::g-name-owner', () => {
                        if (!this._proxy.g_name_owner) {
                            this._setConnected(false);
                            this._statusLabel.text = _('acpd offline');
                        } else {
                            this._statusLabel.text = _('acpd online');
                            this._refreshState();
                            this._call('Connect').catch(() => {});
                        }
                    });
                    if (this._proxy.g_name_owner) {
                        this._statusLabel.text = _('acpd online');
                        this._refreshState();
                        this._call('Connect').catch(() => {});
                    } else {
                        this._statusLabel.text = _('acpd offline — uruchom daemon');
                    }
                    this._refreshPresets();
                } catch (e) {
                    this._statusLabel.text = _('Błąd D-Bus');
                }
            }
        );
    }

    _refreshState() {
        if (!this._proxy) return;
        this._proxy.call('GetState', null, Gio.DBusCallFlags.NONE, -1, null, (p, res) => {
            try {
                let [json] = p.call_finish(res).deep_unpack();
                this._applyState(json);
            } catch (e) {}
        });
        this._proxy.call('IsConnected', null, Gio.DBusCallFlags.NONE, -1, null, (p, res) => {
            try {
                let [c] = p.call_finish(res).deep_unpack();
                this._setConnected(c);
            } catch (e) {}
        });
        this._refreshPresets();
    }

    _refreshPresets() {
        if (!this._proxy || !this._presetsSection) return;
        this._proxy.call('ListPresets', null, Gio.DBusCallFlags.NONE, -1, null, (p, res) => {
            try {
                let [names] = p.call_finish(res).deep_unpack();
                this._presetsSection.removeAll();
                if (!names || !names.length) {
                    this._presetsSection.addMenuItem(
                        new PopupMenu.PopupMenuItem(_('(brak)'), { reactive: false }));
                    return;
                }
                names.forEach(name => {
                    let item = new PopupMenu.PopupMenuItem(`  ${name}`);
                    item.connect('activate', () => {
                        this._call('LoadPreset', new GLib.Variant('(s)', [name])).then(ok => {
                            if (ok) this._refreshState();
                            if (this._settings.get_boolean('show-notifications'))
                                Main.notify('MVSilicon ACP', ok ? `Preset: ${name}` : _('Błąd'));
                        }).catch(() => {});
                    });
                    this._presetsSection.addMenuItem(item);
                });
            } catch (e) {}
        });
    }

    _applyState(jsonStr) {
        try { this._state = JSON.parse(jsonStr); } catch (e) { return; }
        this._applyingState = true;
        try {
            for (let key of Object.keys(this._switches)) {
                if (key in this._state) {
                    let on = !!this._state[key];
                    if (this._switches[key].state !== on)
                        this._switches[key].setToggleState(on);
                }
            }
            for (let key of Object.keys(this._sliders)) {
                if (key in this._state)
                    this._sliders[key].setValue(this._state[key]);
            }
        } finally {
            this._applyingState = false;
        }
    }

    _setConnected(c) {
        this._connected = !!c;
        if (this._statusLabel) {
            this._statusLabel.text = this._connected
                ? _('✔ Połączono z BP1048B2')
                : _('✗ DSP rozłączone');
        }
        if (this._icon)
            this._icon.opacity = this._connected ? 255 : 140;
    }

    _openFullEditor() {
        let path = this._settings.get_string('full-editor-path');
        let candidates = [];
        if (path && path.startsWith('/'))
            candidates.push(path);
        else {
            let name = path || 'acp_gui_gtk.py';
            candidates.push(
                GLib.build_filenamev([GLib.get_home_dir(), '.local', 'share', 'mvsilicon-acp', name]),
                `/usr/share/mvsilicon-acp/${name}`,
                name
            );
        }
        let run = null;
        for (let c of candidates) {
            if (c.startsWith('/') && !GLib.file_test(c, GLib.FileTest.EXISTS))
                continue;
            run = c;
            break;
        }
        if (!run) {
            Main.notify('MVSilicon ACP', _('Nie znaleziono edytora GTK'));
            return;
        }
        try {
            let argv = run.endsWith('.py') ? ['python3', run] : [run];
            Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE);
        } catch (e) {
            Main.notify('MVSilicon ACP', `Błąd: ${e.message}`);
        }
    }

    destroy() {
        for (let id of Object.values(this._debounceTimers)) {
            if (id) GLib.source_remove(id);
        }
        this._proxy = null;
        super.destroy();
    }
});

export default class MvsiliconAcpExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._indicator = new AcpIndicator(this._settings, this);
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
        this._settings = null;
    }
}
