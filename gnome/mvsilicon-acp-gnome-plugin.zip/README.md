# MVSilicon BP1048B2 — GNOME ACP (aplet + daemon + GTK)

Trójwarstwowy sterownik efektów DSP **bez konfliktu o USB**:

| Warstwa | Plik | Rola |
|---------|------|------|
| **Daemon** | `acpd.py` | Jedyny proces z otwartym USB iface 4 (HID/ACP). D-Bus `org.mvsilicon.Acp` |
| **Aplet** | `mvsilicon-acp@mvsilicon/` | GNOME Shell — szybkie przełączniki / suwaki / presety w panelu |
| **Edytor** | `acp_gui_gtk.py` | Pełne okno GTK4/Adwaita (undock z apletu). **Bez PyQt5** |

Opcjonalnie możesz nadal odpalać stary `acp_gui_qt2.py`, ale najpierw wołaj `RequestLock()` na daemonie, żeby oddał uchwyt USB.

## Wymagania

```bash
sudo apt install python3-gi gir1.2-glib-2.0 gir1.2-gtk-4.0 gir1.2-adw-1
pip install pyusb --break-system-packages   # tylko dla acpd
# udev — patrz install/99-mvsilicon-bp1048.rules
```

## Instalacja (1 komenda)

```bash
chmod +x install/install.sh
./install/install.sh
gnome-extensions enable mvsilicon-acp@mvsilicon
# X11: Alt+F2 → r → Enter    |  Wayland: wyloguj/zaloguj
```

Skrypt kopiuje pliki do `~/.local/share/`, włącza `mvsilicon-acpd.service` (systemd --user) i kompiluje schema GSettings.

## Architektura D-Bus

```
org.mvsilicon.Acp  /org/mvsilicon/Acp1  (session bus)

Connect() / Disconnect() / IsConnected() → b
SetParam(s key, i value) → b
GetState() → s   (JSON całego stanu)
ListPresets() → as
LoadPreset(s name) → b
SaveFlash() → b
RequestLock(s owner) / ReleaseLock(s owner)   # dla pełnego edytora Qt ze sniffem
IsLocked() → b, s

sygnały: StateChanged(s), ConnectedChanged(b)
```

Klucze parametrów są te same co w `acp_gui_qt2.py` / `DEFAULT_STATE` (np. `mus_vbass_en`, `gain_mic`, …).

## Tryb prosty (panel)

- Status połączenia DSP  
- Lista presetów (z `~/.config/mvsilicon-acp/presets.json`)  
- Virtual Bass / 3D / Stereo / Voice Cut·Remove / DRC  
- Mic: NS, Howling, Echo, Plate, AutoTune  
- Gain Music / Mic  
- Zapisz flash + **Otwórz pełny edytor**

## Tryb pełny (undock)

Aplet → „Otwórz pełny edytor” uruchamia `acp_gui_gtk.py` (3 zakładki: Mic / Music / Gain, presety, flash).  
Wszystko idzie przez ten sam daemon — możesz mieć aplet i okno otwarte naraz.

## Test ręczny

```bash
# daemon na pierwszym planie
python3 acpd.py

# w drugim terminalu
python3 acp_gui_gtk.py
busctl --user introspect org.mvsilicon.Acp /org/mvsilicon/Acp1
```

## Pliki

```
acpd.py                          # daemon USB + D-Bus
acp_gui_gtk.py                   # floating GTK4 editor
mvsilicon-acp@mvsilicon/         # GNOME Shell extension
  extension.js
  prefs.js
  metadata.json
  schemas/…
install/
  install.sh
  mvsilicon-acpd.service         # systemd --user
  org.mvsilicon.Acp.service      # D-Bus activation
  99-mvsilicon-bp1048.rules      # udev
```

## Uwagi

- **Audio (iface 0–3) nie jest ruszane** — claim tylko iface 4.  
- Daemon polluje obecność urządzenia co 3 s i auto-reconnect.  
- Stan + presety: `~/.config/mvsilicon-acp/`.  
- Stary Qt workbench możesz zostawić do debug/sniffera; produkcyjnie wystarczy GTK + aplet.
